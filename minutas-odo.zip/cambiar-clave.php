<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
security_headers();
$u = require_login_page();

$error = null; $ok = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $actual = (string)($_POST['actual'] ?? '');
    $nueva  = (string)($_POST['nueva'] ?? '');
    $rep    = (string)($_POST['repetir'] ?? '');
    $st = db()->prepare('SELECT pass_hash FROM usuarios WHERE id=?');
    $st->execute([$u['id']]);
    $hash = (string)$st->fetchColumn();
    if (!check_csrf($_POST['csrf'] ?? null))            $error = 'La sesión expiró. Vuelva a intentarlo.';
    elseif (!password_verify($actual, $hash))           $error = 'La clave actual no es correcta.';
    elseif (strlen($nueva) < 8)                        $error = 'La nueva clave debe tener al menos 8 caracteres.';
    elseif (!preg_match('/[A-Za-z]/', $nueva) || !preg_match('/\d/', $nueva)) $error = 'La nueva clave debe combinar letras y números.';
    elseif ($nueva !== $rep)                            $error = 'La confirmación no coincide.';
    elseif (password_verify($nueva, $hash))             $error = 'La nueva clave debe ser distinta de la actual.';
    else {
        db()->prepare('UPDATE usuarios SET pass_hash=?, debe_cambiar=0 WHERE id=?')
            ->execute([password_hash($nueva, PASSWORD_DEFAULT), $u['id']]);
        bitacora('cambio_clave');
        session_regenerate_id(true);
        $ok = true;
    }
}
$st = db()->prepare('SELECT debe_cambiar FROM usuarios WHERE id=?');
$st->execute([$u['id']]);
$forzado = (bool)$st->fetchColumn();
?><!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cambiar clave · Minutas ODO</title><link rel="stylesheet" href="assets/app.css"></head>
<body class="auth"><main class="auth-card">
  <div class="brand"><span class="brand-inf">∞</span><span class="brand-word">Odo</span></div>
  <h1>Cambiar clave</h1>
  <p class="muted"><?= h($u['email']) ?></p>
  <?php if ($ok): ?>
    <p class="alert ok">Clave actualizada.</p>
    <a class="btn primary block" href="index.php">Continuar</a>
  <?php else: ?>
    <?php if ($forzado): ?><p class="alert warn">Por seguridad debe reemplazar la clave inicial antes de continuar.</p><?php endif; ?>
    <?php if ($error): ?><p class="alert err"><?= h($error) ?></p><?php endif; ?>
    <form method="post">
      <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
      <label>Clave actual<input type="password" name="actual" required autofocus></label>
      <label>Nueva clave <small>(mínimo 8 caracteres, letras y números)</small><input type="password" name="nueva" required minlength="8"></label>
      <label>Repetir nueva clave<input type="password" name="repetir" required minlength="8"></label>
      <button class="btn primary block" type="submit">Guardar</button>
    </form>
    <?php if (!$forzado): ?><p><a href="index.php">Volver</a></p><?php endif; ?>
  <?php endif; ?>
</main></body></html>
