<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
security_headers();
$u = require_login_page();
$st = db()->prepare('SELECT debe_cambiar FROM usuarios WHERE id=?');
$st->execute([$u['id']]);
if ((int)$st->fetchColumn() === 1) { header('Location: cambiar-clave.php'); exit; }
$v = APP_VERSION;
?><!doctype html>
<html lang="es"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Minutas ODO</title>
<link rel="stylesheet" href="assets/app.css?v=<?= $v ?>">
</head><body>
<header class="top"><div class="in">
  <div class="brand"><span class="brand-inf">∞</span><span class="brand-word">Odo</span></div>
  <div class="sub">Minutas de compraventa de acciones</div>
  <nav class="menu" id="menu">
    <a href="#/nueva" data-r="nueva">Nueva minuta</a>
    <a href="#/operaciones" data-r="operaciones">Operaciones</a>
    <a href="#/compradores" data-r="compradores">Compradores</a>
    <?php if ($u['rol'] === 'master'): ?>
    <a href="#/ajustes" data-r="ajustes">Ajustes</a>
    <a href="#/usuarios" data-r="usuarios">Usuarios</a>
    <a href="#/bitacora" data-r="bitacora">Bitácora</a>
    <?php endif; ?>
  </nav>
  <div class="usr"><button id="usrBtn" type="button"><?= h($u['nombre']) ?> ▾</button>
    <div class="dd" id="usrDd">
      <a href="cambiar-clave.php">Cambiar clave</a>
      <a href="logout.php">Salir</a>
    </div>
  </div>
</div></header>
<main class="app" id="app"><p class="muted">Cargando…</p></main>
<script src="assets/vendor/pdfmake.min.js?v=<?= $v ?>"></script>
<script src="assets/vendor/vfs_serif.js?v=<?= $v ?>"></script>
<script src="assets/minuta.js?v=<?= $v ?>"></script>
<script src="assets/app.js?v=<?= $v ?>"></script>
</body></html>
