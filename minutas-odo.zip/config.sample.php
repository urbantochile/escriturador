<?php
/*
 * Minutas ODO — configuración del servidor.
 * Copie este archivo como config.php y complete los datos de la base MySQL
 * creada en SiteGround (Site Tools → Sitio → MySQL).
 * Los datos de ODO, IVELSA, medios de pago y representantes NO van aquí:
 * se editan desde la aplicación, en «Ajustes».
 */
return [
    'db' => [
        'host'     => 'localhost',
        'port'     => 3306,
        'name'     => 'NOMBRE_DE_LA_BASE',
        'user'     => 'USUARIO_DE_LA_BASE',
        'password' => 'CONTRASEÑA_DE_LA_BASE',
    ],

    // Carpeta donde se archivan los PDF generados. Idealmente FUERA de public_html,
    // p. ej. '/home/customer/minutas-storage'. Si se deja la carpeta interna,
    // el .htaccess incluido bloquea el acceso directo.
    'storage_dir' => __DIR__ . '/storage',

    // Zona horaria para fechas y folios.
    'timezone' => 'America/Santiago',

    // Nombre de la cookie de sesión.
    'session_name' => 'odo_minutas',
];
