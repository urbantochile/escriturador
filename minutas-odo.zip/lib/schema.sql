CREATE TABLE IF NOT EXISTS usuarios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL UNIQUE,
  nombre VARCHAR(190) NOT NULL,
  rol ENUM('master','usuario') NOT NULL DEFAULT 'usuario',
  pass_hash VARCHAR(255) NOT NULL,
  debe_cambiar TINYINT(1) NOT NULL DEFAULT 1,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  intentos_fallidos INT NOT NULL DEFAULT 0,
  bloqueado_hasta DATETIME NULL,
  ultimo_ingreso DATETIME NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS compradores (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tipo ENUM('natural','juridica') NOT NULL,
  doc_tipo ENUM('rut','pasaporte') NOT NULL DEFAULT 'rut',
  documento VARCHAR(40) NOT NULL,
  nombre VARCHAR(255) NOT NULL,
  email VARCHAR(190) NOT NULL,
  telefono VARCHAR(60) NULL,
  comuna VARCHAR(120) NULL,
  region VARCHAR(120) NULL,
  datos JSON NOT NULL,
  creado_por INT UNSIGNED NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_documento (doc_tipo, documento),
  KEY ix_nombre (nombre)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS operaciones (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  folio VARCHAR(40) NOT NULL UNIQUE,
  serie ENUM('B','C') NOT NULL,
  comprador_id INT UNSIGNED NOT NULL,
  cantidad BIGINT UNSIGNED NOT NULL,
  precio_unitario BIGINT UNSIGNED NOT NULL,
  total BIGINT UNSIGNED NOT NULL,
  forma_pago ENUM('contado','parcial') NOT NULL,
  fecha_contrato DATE NOT NULL,
  estado ENUM('borrador','generada','firmada','anulada') NOT NULL DEFAULT 'borrador',
  motivo_anulacion VARCHAR(500) NULL,
  datos JSON NOT NULL,
  pdf_archivo VARCHAR(255) NULL,
  pdf_sha256 CHAR(64) NULL,
  version INT UNSIGNED NOT NULL DEFAULT 0,
  creado_por INT UNSIGNED NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY ix_serie_estado (serie, estado),
  CONSTRAINT fk_op_comprador FOREIGN KEY (comprador_id) REFERENCES compradores(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ajustes (
  clave VARCHAR(80) PRIMARY KEY,
  valor TEXT NOT NULL,
  actualizado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bitacora (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED NULL,
  accion VARCHAR(80) NOT NULL,
  detalle JSON NULL,
  ip VARCHAR(64) NULL,
  creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY ix_fecha (creado_en)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
