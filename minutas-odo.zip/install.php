<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
security_headers();

$msg = []; $ok = false; $error = null;

if (is_installed()) {
    $error = 'La plataforma ya está instalada. Por seguridad, elimine install.php del servidor.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = db();
        $msg[] = 'Conexión a MySQL correcta.';
        $sql = file_get_contents(__DIR__ . '/lib/schema.sql');
        foreach (array_filter(array_map('trim', explode(';', $sql))) as $stmt) $pdo->exec($stmt);
        $msg[] = 'Tablas creadas.';

        $n = (int)$pdo->query("SELECT COUNT(*) FROM usuarios WHERE rol='master'")->fetchColumn();
        if ($n === 0) {
            $st = $pdo->prepare('INSERT INTO usuarios (email, nombre, rol, pass_hash, debe_cambiar) VALUES (?,?,?,?,1)');
            $st->execute(['master@odo.cl', 'Máster', 'master', password_hash('123odo', PASSWORD_DEFAULT)]);
            $msg[] = 'Usuario máster creado: master@odo.cl (clave inicial 123odo; se exige cambiarla al primer ingreso).';
        } else {
            $msg[] = 'Ya existía un usuario máster; no se modificó.';
        }

        $defaults = require __DIR__ . '/lib/defaults.php';
        $st = $pdo->prepare('INSERT IGNORE INTO ajustes (clave, valor) VALUES (?,?)');
        foreach ($defaults as $k => $v) $st->execute([$k, $v]);
        $msg[] = 'Ajustes iniciales cargados.';

        $dir = storage_dir('minutas');
        if (!is_writable($dir)) throw new RuntimeException("La carpeta de almacenamiento no tiene permiso de escritura: $dir");
        file_put_contents(storage_dir() . '/.instalado', date('c'));
        $msg[] = 'Carpeta de archivo de minutas lista.';
        $ok = true;
    } catch (Throwable $e) {
        $error = 'Error: ' . $e->getMessage();
    }
}
?><!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Instalación · Minutas ODO</title><link rel="stylesheet" href="assets/app.css"></head>
<body class="auth"><main class="auth-card">
  <div class="brand"><span class="brand-inf">∞</span><span class="brand-word">Odo</span></div>
  <h1>Instalación</h1>
  <?php if ($error): ?><p class="alert err"><?= h($error) ?></p><?php endif; ?>
  <?php foreach ($msg as $m): ?><p class="alert ok"><?= h($m) ?></p><?php endforeach; ?>
  <?php if ($ok): ?>
    <p><strong>Listo.</strong> Elimine ahora el archivo <code>install.php</code> del servidor y luego ingrese.</p>
    <a class="btn primary" href="login.php">Ir al ingreso</a>
  <?php elseif (!is_installed()): ?>
    <p>Se crearán las tablas en la base configurada en <code>config.php</code>, el usuario máster y los ajustes iniciales.</p>
    <form method="post"><button class="btn primary" type="submit">Instalar</button></form>
  <?php endif; ?>
</main></body></html>
