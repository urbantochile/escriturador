/* Minutas ODO — aplicación (formulario, base de compradores, operaciones, administración) */
(() => {
  'use strict';
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmt = n => Minuta.fmt(n);
  const APP = $('#app');
  const WIP_KEY = 'odo_minuta_wip';
  let SES = null;
  let S = null; // estado del formulario en curso

  const hoy = () => new Date().toLocaleDateString('sv-SE', { timeZone: 'America/Santiago' });

  // ── API ────────────────────────────────────────────────────────────────
  async function api(a, { method = 'GET', body, params = '' } = {}) {
    const r = await fetch(`api.php?a=${a}${params}`, {
      method, credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-CSRF': SES ? SES.csrf : '' },
      body: body ? JSON.stringify(body) : undefined,
    });
    if (r.status === 401) { location.href = 'login.php'; throw new Error('Sesión expirada'); }
    let j = {};
    try { j = await r.json(); } catch (e) { throw new Error('Respuesta inválida del servidor'); }
    if (r.status === 403 && /cambiar su clave/.test(j.error || '')) { location.href = 'cambiar-clave.php'; }
    if (!r.ok) throw new Error(j.error || `Error ${r.status}`);
    return j;
  }

  function toast(msg, err) {
    $$('.toast').forEach(x => x.remove());
    const t = document.createElement('div');
    t.className = 'toast' + (err ? ' err' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), err ? 5200 : 3000);
  }

  function modal(html, onMount) {
    const m = document.createElement('div');
    m.className = 'modal';
    m.innerHTML = `<div class="box">${html}</div>`;
    document.body.appendChild(m);
    const close = () => m.remove();
    m.addEventListener('click', e => { if (e.target === m) close(); });
    if (onMount) onMount(m, close);
    return close;
  }
  function confirmar(titulo, texto, { ok = 'Confirmar', peligro = false, motivo = false } = {}) {
    return new Promise(res => {
      modal(`<h2>${esc(titulo)}</h2><p>${texto}</p>${motivo ? '<label>Motivo<textarea id="mMot" required></textarea></label>' : ''}
        <div class="row end"><button class="btn" data-x>Cancelar</button><button class="btn ${peligro ? 'peligro' : 'primary'}" data-ok>${esc(ok)}</button></div>`,
      (m, close) => {
        $('[data-x]', m).onclick = () => { close(); res(null); };
        $('[data-ok]', m).onclick = () => {
          const v = motivo ? $('#mMot', m).value.trim() : true;
          if (motivo && v.length < 5) { $('#mMot', m).classList.add('invalido'); return; }
          close(); res(v);
        };
      });
    });
  }

  // ── RUT ────────────────────────────────────────────────────────────────
  function rutLimpio(r) { return String(r || '').replace(/[^0-9kK]/g, '').toUpperCase(); }
  function rutValido(r) {
    const c = rutLimpio(r); if (c.length < 2) return false;
    const cuerpo = c.slice(0, -1), dv = c.slice(-1);
    if (!/^\d+$/.test(cuerpo)) return false;
    let s = 0, m = 2;
    for (let i = cuerpo.length - 1; i >= 0; i--) { s += +cuerpo[i] * m; m = m === 7 ? 2 : m + 1; }
    const d = 11 - (s % 11);
    return (d === 11 ? '0' : d === 10 ? 'K' : String(d)) === dv;
  }
  function rutFormato(r) {
    const c = rutLimpio(r); if (c.length < 2) return r;
    return fmt(+c.slice(0, -1)) + '-' + c.slice(-1);
  }
  const emailValido = e => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(e || '').trim());

  // ── Catálogos ──────────────────────────────────────────────────────────
  const REGIONES = ['Región de Arica y Parinacota', 'Región de Tarapacá', 'Región de Antofagasta', 'Región de Atacama', 'Región de Coquimbo',
    'Región de Valparaíso', 'Región Metropolitana de Santiago', "Región del Libertador General Bernardo O'Higgins", 'Región del Maule',
    'Región de Ñuble', 'Región del Biobío', 'Región de La Araucanía', 'Región de Los Ríos', 'Región de Los Lagos',
    'Región de Aysén del General Carlos Ibáñez del Campo', 'Región de Magallanes y de la Antártica Chilena', 'Extranjero'];
  const EC = [['', '— seleccione —'], ['soltero', 'Soltero(a)'], ['casado', 'Casado(a)'], ['divorciado', 'Divorciado(a)'], ['viudo', 'Viudo(a)'], ['conviviente', 'Conviviente civil']];
  const REG = [['', '— seleccione —'], ['sociedad', 'Sociedad conyugal'], ['separacion', 'Separación total de bienes'], ['gananciales', 'Participación en los gananciales']];
  const PASOS = ['Serie', 'Comprador', 'Operación y pago', 'Declaraciones', 'Revisión y PDF'];

  // ── Estado del formulario ──────────────────────────────────────────────
  function nuevoEstado(serie) {
    const A = SES.ajustes;
    return {
      id: null, folio: null, version: 0, paso: serie ? 1 : 0, mostrarErrores: false,
      comprador: { tipo: 'natural', trat: 'don', doc_tipo: 'rut', documento: '', nombre: '', nacionalidad: 'chileno', estado_civil: '', regimen: '',
        profesion: '', domicilio: '', comuna: '', region: 'Región Metropolitana de Santiago', email: '', telefono: '', giro: '',
        rep_trat: 'don', rep_nombre: '', rep_nacionalidad: 'chileno', rep_estado_civil: '', rep_regimen: '', rep_profesion: '', rep_documento: '',
        pers_tipo: 'res', pers_fecha: '', pers_notaria: '', pers_repertorio: '', pers_cve: '', pers_texto: '' },
      operacion: { serie: serie || '', cantidad: '', precio: '', ronda: '', acuerdo_dir: false, acuerdo_fecha: '', fecha_contrato: hoy(),
        forma_pago: 'contado', pago_medio: 'transferencia', pago_fecha: hoy(), pie_monto: '', pie_medio: 'transferencia', pie_fecha: hoy(),
        cuotas_n: 12, periodicidad: 'mensuales', cuota_primera: '', reajuste_uf: true, origen_fondos: '', inversion_ext: 'A',
        dias_registro: A.dias_registro || '5', testigos_incluir: false, testigos: [{ nombre: '', rut: '' }, { nombre: '', rut: '' }],
        tenencia_vendedor: '', agente: '', notas: '' },
    };
  }
  function guardarWip() { try { if (S) localStorage.setItem(WIP_KEY, JSON.stringify(S)); } catch (e) { /* sin almacenamiento */ } }
  function leerWip() { try { const j = localStorage.getItem(WIP_KEY); return j ? JSON.parse(j) : null; } catch (e) { return null; } }
  function borrarWip() { try { localStorage.removeItem(WIP_KEY); } catch (e) { /* nada */ } }

  const getP = (o, p) => p.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
  function setP(o, p, v) { const ks = p.split('.'); const last = ks.pop(); const t = ks.reduce((a, k) => a[k], o); t[last] = v; }

  const num = v => { const n = parseInt(String(v ?? '').replace(/[^\d]/g, ''), 10); return isNaN(n) ? 0 : n; };
  function calc() {
    const o = S.operacion, A = SES.ajustes;
    const cantidad = num(o.cantidad), precio = num(o.precio), total = cantidad * precio;
    const pie = num(o.pie_monto), saldo = Math.max(0, total - pie);
    const plan = o.forma_pago === 'parcial' && o.cuota_primera ? Minuta.planCuotas(saldo, num(o.cuotas_n), o.cuota_primera, o.periodicidad) : null;
    const pct = parseFloat(String(A.c_recargo_tarjeta).replace(',', '.')) || 0;
    const conRecargo = m => Math.round(m * (1 + pct / 100));
    let disp = SES.cupos[o.serie] ? SES.cupos[o.serie].disponible : 0;
    if (S.estadoOriginal === 'generada' && S.serieOriginal === o.serie) disp += num(S.cantidadOriginal);
    return { cantidad, precio, total, pie, saldo, plan, pct, conRecargo, disponible: disp };
  }

  // ── Validación ─────────────────────────────────────────────────────────
  function validar() {
    const E = [];
    const c = S.comprador, o = S.operacion, A = SES.ajustes, k = calc();
    const req = (paso, campo, v, msg) => { if (!String(v ?? '').trim()) E.push({ paso, campo, msg }); };
    if (!o.serie) E.push({ paso: 0, campo: 'operacion.serie', msg: 'Elija la serie de acciones' });

    // Comprador
    if (c.tipo === 'natural') {
      req(1, 'comprador.nombre', c.nombre, 'Nombre completo del comprador');
      if (c.nombre && c.nombre.trim().split(/\s+/).length < 2) E.push({ paso: 1, campo: 'comprador.nombre', msg: 'Indique nombres y apellidos del comprador' });
      req(1, 'comprador.nacionalidad', c.nacionalidad, 'Nacionalidad del comprador');
      req(1, 'comprador.estado_civil', c.estado_civil, 'Estado civil del comprador');
      if (c.estado_civil === 'casado') req(1, 'comprador.regimen', c.regimen, 'Régimen de bienes del comprador');
      req(1, 'comprador.profesion', c.profesion, 'Profesión u oficio del comprador');
      if (c.doc_tipo === 'rut') { if (!rutValido(c.documento)) E.push({ paso: 1, campo: 'comprador.documento', msg: 'RUN del comprador inválido' }); }
      else if (String(c.documento).trim().length < 5) E.push({ paso: 1, campo: 'comprador.documento', msg: 'Número de pasaporte del comprador' });
    } else {
      req(1, 'comprador.nombre', c.nombre, 'Razón social del comprador');
      if (!rutValido(c.documento)) E.push({ paso: 1, campo: 'comprador.documento', msg: 'RUT de la sociedad compradora inválido' });
      req(1, 'comprador.giro', c.giro, 'Giro de la sociedad compradora');
      req(1, 'comprador.rep_nombre', c.rep_nombre, 'Nombre del representante');
      req(1, 'comprador.rep_nacionalidad', c.rep_nacionalidad, 'Nacionalidad del representante');
      req(1, 'comprador.rep_estado_civil', c.rep_estado_civil, 'Estado civil del representante');
      if (c.rep_estado_civil === 'casado') req(1, 'comprador.rep_regimen', c.rep_regimen, 'Régimen de bienes del representante');
      req(1, 'comprador.rep_profesion', c.rep_profesion, 'Profesión del representante');
      if (!rutValido(c.rep_documento)) E.push({ paso: 1, campo: 'comprador.rep_documento', msg: 'RUN del representante inválido' });
      if (c.pers_tipo === 'escritura') { req(1, 'comprador.pers_fecha', c.pers_fecha, 'Fecha de la escritura de personería'); req(1, 'comprador.pers_notaria', c.pers_notaria, 'Notaría de la escritura de personería'); }
      else if (c.pers_tipo === 'res') { req(1, 'comprador.pers_fecha', c.pers_fecha, 'Fecha del certificado de poderes'); req(1, 'comprador.pers_cve', c.pers_cve, 'Código CVE del certificado'); }
      else req(1, 'comprador.pers_texto', c.pers_texto, 'Instrumento donde consta la personería');
    }
    req(1, 'comprador.domicilio', c.domicilio, 'Domicilio (calle y número)');
    req(1, 'comprador.comuna', c.comuna, c.region === 'Extranjero' ? 'Ciudad y país' : 'Comuna');
    req(1, 'comprador.region', c.region, 'Región');
    if (!emailValido(c.email)) E.push({ paso: 1, campo: 'comprador.email', msg: 'Correo electrónico del comprador inválido' });

    // Operación
    if (k.cantidad <= 0) E.push({ paso: 2, campo: 'operacion.cantidad', msg: 'Cantidad de acciones' });
    else if (o.serie && k.cantidad > k.disponible) E.push({ paso: 2, campo: 'operacion.cantidad', msg: `La cantidad supera las ${fmt(k.disponible)} acciones disponibles de la Serie ${o.serie}` });
    if (k.precio <= 0) E.push({ paso: 2, campo: 'operacion.precio', msg: 'Precio por acción' });
    else if (o.serie === 'C' && k.precio < num(A.c_precio_minimo)) E.push({ paso: 2, campo: 'operacion.precio', msg: `El precio Serie C no puede ser inferior a $${fmt(A.c_precio_minimo)} (Art. Sexto N° Cuatro)` });
    req(2, 'operacion.fecha_contrato', o.fecha_contrato, 'Fecha del contrato');
    if (o.serie === 'C' && o.fecha_contrato > A.c_plazo_maximo) E.push({ paso: 2, campo: 'operacion.fecha_contrato', msg: 'La Serie C sólo puede colocarse hasta el ' + Minuta.fechaCorta(A.c_plazo_maximo) });
    if (o.serie === 'C' && o.acuerdo_dir) {
      req(2, 'operacion.acuerdo_fecha', o.acuerdo_fecha, 'Fecha de la sesión de directorio');
      if (o.acuerdo_fecha && o.acuerdo_fecha > o.fecha_contrato) E.push({ paso: 2, campo: 'operacion.acuerdo_fecha', msg: 'La sesión de directorio no puede ser posterior al contrato' });
    }
    if (o.serie === 'B') {
      const ten = num(o.tenencia_vendedor);
      if (ten <= 0) E.push({ paso: 2, campo: 'operacion.tenencia_vendedor', msg: 'Acciones Serie B de que es dueño el vendedor' });
      else if (k.cantidad > ten) E.push({ paso: 2, campo: 'operacion.cantidad', msg: 'La cantidad supera las acciones de que es dueño el vendedor' });
    }
    if (o.forma_pago === 'contado') {
      req(2, 'operacion.pago_fecha', o.pago_fecha, 'Fecha del pago');
      if (o.pago_fecha && o.fecha_contrato && o.pago_fecha > o.fecha_contrato) E.push({ paso: 2, campo: 'operacion.pago_fecha', msg: 'El pago al contado no puede ser posterior al contrato: el contrato declara el precio ya recibido' });
    } else {
      if (k.pie <= 0 || k.pie >= k.total) E.push({ paso: 2, campo: 'operacion.pie_monto', msg: 'El pago inicial debe ser mayor que cero y menor que el total' });
      req(2, 'operacion.pie_fecha', o.pie_fecha, 'Fecha del pago inicial');
      if (o.pie_fecha && o.fecha_contrato && o.pie_fecha > o.fecha_contrato) E.push({ paso: 2, campo: 'operacion.pie_fecha', msg: 'El pago inicial no puede ser posterior al contrato: el contrato lo declara recibido' });
      const n = num(o.cuotas_n);
      if (n < 1 || n > 120) E.push({ paso: 2, campo: 'operacion.cuotas_n', msg: 'Número de cuotas entre 1 y 120' });
      req(2, 'operacion.cuota_primera', o.cuota_primera, 'Vencimiento de la primera cuota');
      if (o.cuota_primera && o.fecha_contrato && o.cuota_primera <= o.fecha_contrato) E.push({ paso: 2, campo: 'operacion.cuota_primera', msg: 'La primera cuota debe vencer después de la fecha del contrato' });
      if (o.serie === 'C' && k.plan && k.plan.ultima > A.c_plazo_maximo) E.push({ paso: 2, campo: 'operacion.cuotas_n', msg: `La última cuota vence el ${Minuta.fechaCorta(k.plan.ultima)}, después del plazo estatutario (${Minuta.fechaCorta(A.c_plazo_maximo)}, Art. Séptimo)` });
    }

    // Declaraciones
    if (String(o.origen_fondos || '').trim().length < 5) E.push({ paso: 3, campo: 'operacion.origen_fondos', msg: 'Origen de los fondos' });
    const d = num(o.dias_registro);
    if (d < 1 || d > 30) E.push({ paso: 3, campo: 'operacion.dias_registro', msg: 'Días hábiles para inscribir (1 a 30)' });
    if (o.serie === 'B' || o.testigos_incluir) {
      o.testigos.forEach((t, i) => {
        if (String(t.nombre || '').trim().split(/\s+/).length < 2) E.push({ paso: 3, campo: `operacion.testigos.${i}.nombre`, msg: `Nombre completo del testigo ${i + 1}` });
        if (!rutValido(t.rut)) E.push({ paso: 3, campo: `operacion.testigos.${i}.rut`, msg: `RUN del testigo ${i + 1} inválido` });
      });
    }

    // Ajustes incompletos que usa esta serie
    const claves = o.serie === 'B'
      ? Object.keys(A).filter(x => /^(iv_|b_|odo_antecedentes|odo_rut|odo_razon|abogado_|ciudad_firma|plataforma_firma)/.test(x))
      : Object.keys(A).filter(x => /^(odo_|c_|abogado_|ciudad_firma|plataforma_firma)/.test(x));
    const faltan = claves.filter(x => /COMPLETAR/i.test(A[x]) || !String(A[x] || '').trim());
    if (faltan.length) E.push({ paso: 4, campo: '', msg: `Faltan datos del vendedor en Ajustes (${faltan.map(x => AJ_LABEL[x] || x).join(', ')})${SES.usuario.rol === 'master' ? '' : ': pida al usuario máster que los complete'}` });
    return E;
  }

  // ── Campos ─────────────────────────────────────────────────────────────
  function invalido(path) { return S.mostrarErrores && S._errs && S._errs.some(e => e.campo === path) ? ' invalido' : ''; }
  function F(path, label, o = {}) {
    let v = getP(S, path) ?? '';
    if (o.num && String(v) !== '') v = fmt(num(v));
    const cls = o.cls || 'c6';
    const inv = invalido(path);
    let ctrl;
    if (o.opts) {
      ctrl = `<select data-p="${path}" class="${inv}" ${o.rr ? 'data-rr' : ''}>${o.opts.map(x => { const [val, lab] = Array.isArray(x) ? x : [x, x]; return `<option value="${esc(val)}" ${String(v) === String(val) ? 'selected' : ''}>${esc(lab)}</option>`; }).join('')}</select>`;
    } else if (o.type === 'textarea') {
      ctrl = `<textarea data-p="${path}" class="${inv}" placeholder="${esc(o.ph || '')}">${esc(v)}</textarea>`;
    } else {
      ctrl = `<input data-p="${path}" class="${inv}" type="${o.type || 'text'}" value="${esc(v)}" placeholder="${esc(o.ph || '')}" ${o.num ? 'data-num inputmode="numeric"' : ''} ${o.rut ? 'data-rut' : ''} ${o.rr ? 'data-rr' : ''} ${o.attrs || ''}>`;
    }
    return `<label class="${cls}">${esc(label)}${o.small ? ` <small>${esc(o.small)}</small>` : ''}${ctrl}${o.hint ? `<div class="hint">${o.hint}</div>` : ''}</label>`;
  }
  function seg(path, opciones) {
    const v = getP(S, path);
    return `<div class="seg">${opciones.map(([val, lab]) => `<label class="${String(v) === String(val) ? 'on' : ''}"><input type="radio" data-p="${path}" data-rr value="${esc(val)}" ${String(v) === String(val) ? 'checked' : ''}>${esc(lab)}</label>`).join('')}</div>`;
  }
  function chk(path, label) {
    return `<label class="check c12"><input type="checkbox" data-p="${path}" data-rr ${getP(S, path) ? 'checked' : ''}>${esc(label)}</label>`;
  }

  // ── Vista: Nueva minuta ────────────────────────────────────────────────
  function vistaNueva() {
    if (!S) {
      const w = leerWip();
      S = w && w.operacion ? w : nuevoEstado();
    }
    renderWizard();
  }

  function renderWizard() {
    S._errs = validar();
    const errPasos = new Set(S._errs.map(e => e.paso));
    const titulo = S.id ? `Editando ${esc(S.folio)}` : 'Nueva minuta';
    const pasos = PASOS.map((p, i) => `<button type="button" data-paso="${i}" class="${i === S.paso ? 'on' : ''} ${S.mostrarErrores && errPasos.has(i) ? 'err' : ''} ${i < S.paso && !errPasos.has(i) ? 'done' : ''}"><b>Paso ${i + 1}</b><span>${p}</span></button>`).join('');
    const cuerpo = [pasoSerie, pasoComprador, pasoOperacion, pasoDeclaraciones, pasoRevision][S.paso]();
    const errsPaso = S.mostrarErrores ? S._errs.filter(e => e.paso === S.paso) : [];
    APP.innerHTML = `
      <div class="row" style="margin-bottom:12px"><h1 style="margin:0">${titulo}</h1>${S.operacion.serie ? `<span class="pill ${S.operacion.serie}">Serie ${S.operacion.serie}</span>` : ''}
        <span class="spacer"></span><button class="btn small" id="descartar">${S.id ? 'Cerrar edición' : 'Descartar y empezar de nuevo'}</button></div>
      <div class="steps">${pasos}</div>
      <div class="card" id="paso">
        ${errsPaso.length && S.paso !== 4 ? `<ul class="errores">${errsPaso.map(e => `<li data-campo="${e.campo}">${esc(e.msg)}</li>`).join('')}</ul>` : ''}
        ${cuerpo}
      </div>
      <div class="wizard-nav">
        <button class="btn" id="ant" ${S.paso === 0 ? 'disabled' : ''}>← Anterior</button>
        ${S.paso < 4 ? `<button class="btn primary" id="sig" ${S.paso === 0 && !S.operacion.serie ? 'disabled' : ''}>Siguiente →</button>` : ''}
      </div>`;
    guardarWip();
  }

  function pasoSerie() {
    const cu = SES.cupos, A = SES.ajustes, sel = S.operacion.serie;
    return `<h2>¿Qué acciones se venden?</h2>
      <div class="series">
        <button type="button" class="serie ${sel === 'C' ? 'on' : ''}" data-serie="C">
          <span class="tag">Serie C</span>
          <h3>Suscripción y compraventa</h3>
          <p><b>Vende:</b> ${esc(A.odo_razon)}</p>
          <p>Colocación de acciones de primera emisión. El precio ingresa a la caja social como capital. Precio mínimo $${fmt(A.c_precio_minimo)} por acción; saldo a plazo hasta el ${Minuta.fechaCorta(A.c_plazo_maximo)}.</p>
          <div class="cupo">Disponibles: ${fmt(cu.C.disponible)} de ${fmt(cu.C.total)}</div>
        </button>
        <button type="button" class="serie ${sel === 'B' ? 'on' : ''}" data-serie="B">
          <span class="tag">Serie B</span>
          <h3>Compraventa y cesión</h3>
          <p><b>Vende:</b> ${esc(A.iv_razon)}</p>
          <p>Traspaso de acciones ya suscritas y pagadas. El precio ingresa al patrimonio del vendedor, no al capital de ODO. Se firma ante dos testigos.</p>
          <div class="cupo">Tenencia del vendedor: ${fmt(cu.B.disponible)} de ${fmt(cu.B.total)}</div>
        </button>
      </div>`;
  }

  function pasoComprador() {
    const c = S.comprador;
    const ec = (p, trat) => EC.map(([v, l]) => [v, v ? Minuta.estadoCivilTexto(v, '', trat).replace(/^./, m => m.toUpperCase()) : l]);
    let h = `<h2>Datos del comprador</h2>
      <div class="grid"><label class="c12">Buscar comprador registrado <small>(RUT, nombre o correo)</small>
        <input id="buscaComp" type="search" placeholder="Escriba al menos 3 caracteres…" autocomplete="off"></label>
        <div class="c12" id="resComp"></div></div>
      <div class="subt">Tipo de comprador</div>${seg('comprador.tipo', [['natural', 'Persona natural'], ['juridica', 'Persona jurídica']])}`;
    if (c.tipo === 'natural') {
      h += `<div class="grid">
        ${F('comprador.trat', 'Tratamiento', { cls: 'c3', opts: [['don', 'Don'], ['doña', 'Doña']], rr: 1 })}
        ${F('comprador.nombre', 'Nombre completo', { cls: 'c8', ph: 'Nombres y apellidos' })}
        ${F('comprador.doc_tipo', 'Documento', { cls: 'c3', opts: [['rut', 'Cédula chilena (RUN)'], ['pasaporte', 'Pasaporte']], rr: 1 })}
        ${F('comprador.documento', c.doc_tipo === 'rut' ? 'RUN' : 'N° de pasaporte', { cls: 'c3', rut: c.doc_tipo === 'rut', ph: c.doc_tipo === 'rut' ? '12.345.678-9' : '' })}
        ${F('comprador.nacionalidad', 'Nacionalidad', { cls: 'c3', ph: 'chileno / chilena' })}
        ${F('comprador.profesion', 'Profesión u oficio', { cls: 'c3', ph: 'ingeniero comercial' })}
        ${F('comprador.estado_civil', 'Estado civil', { cls: c.estado_civil === 'casado' ? 'c6' : 'c12', opts: ec('comprador.estado_civil', c.trat), rr: 1 })}
        ${c.estado_civil === 'casado' ? F('comprador.regimen', 'Régimen de bienes', { cls: 'c6', opts: REG }) : ''}
      </div>`;
    } else {
      h += `<div class="grid">
        ${F('comprador.nombre', 'Razón social', { cls: 'c8' })}
        ${F('comprador.documento', 'RUT', { cls: 'c4', rut: 1, ph: '76.123.456-7' })}
        ${F('comprador.giro', 'Giro', { cls: 'c12', ph: 'inversiones' })}
      </div>`;
    }
    h += `<div class="subt">Domicilio y contacto</div><div class="grid">
      ${F('comprador.domicilio', 'Calle, número, depto./oficina', { cls: 'c12' })}
      ${F('comprador.comuna', c.region === 'Extranjero' ? 'Ciudad y país' : 'Comuna', { cls: 'c4' })}
      ${F('comprador.region', 'Región', { cls: 'c8', opts: REGIONES, rr: 1 })}
      ${F('comprador.email', 'Correo electrónico', { cls: 'c6', type: 'email', hint: 'Será el correo oficial registrado (Art. Vigésimo Segundo) y el de firma en FirmaYa.' })}
      ${F('comprador.telefono', 'Teléfono', { cls: 'c6', small: '(solo base de datos)', ph: '+56 9 …' })}
    </div>`;
    if (c.tipo === 'juridica') {
      h += `<div class="subt">Representante legal</div><div class="grid">
        ${F('comprador.rep_trat', 'Tratamiento', { cls: 'c3', opts: [['don', 'Don'], ['doña', 'Doña']], rr: 1 })}
        ${F('comprador.rep_nombre', 'Nombre completo', { cls: 'c6' })}
        ${F('comprador.rep_documento', 'RUN', { cls: 'c3', rut: 1 })}
        ${F('comprador.rep_nacionalidad', 'Nacionalidad', { cls: 'c4' })}
        ${F('comprador.rep_profesion', 'Profesión u oficio', { cls: 'c4' })}
        ${F('comprador.rep_estado_civil', 'Estado civil', { cls: 'c4', opts: ec('comprador.rep_estado_civil', c.rep_trat), rr: 1 })}
        ${c.rep_estado_civil === 'casado' ? F('comprador.rep_regimen', 'Régimen de bienes', { cls: 'c6', opts: REG }) : ''}
      </div>
      <div class="subt">Personería del representante</div>${seg('comprador.pers_tipo', [['res', 'Certificado RES (Empresa en un Día)'], ['escritura', 'Escritura pública'], ['otro', 'Otro']])}
      <div class="grid">`;
      if (c.pers_tipo === 'res') h += F('comprador.pers_fecha', 'Fecha del certificado', { cls: 'c4', type: 'date' }) + F('comprador.pers_cve', 'Código CVE', { cls: 'c8' });
      else if (c.pers_tipo === 'escritura') h += F('comprador.pers_fecha', 'Fecha de la escritura', { cls: 'c4', type: 'date' }) + F('comprador.pers_notaria', 'Notaría', { cls: 'c4', ph: 'Santiago de don Juan Pérez' }) + F('comprador.pers_repertorio', 'Repertorio', { cls: 'c4', small: '(opcional)' });
      else h += F('comprador.pers_texto', 'Instrumento donde consta', { cls: 'c12', type: 'textarea' });
      h += '</div>';
    }
    return h;
  }

  function bloqueCalc() {
    const k = calc(), o = S.operacion, A = SES.ajustes;
    let h = `<div class="calc" id="calc"><div class="row"><div><div class="muted">Total</div><div class="big">$${fmt(k.total)}</div></div>
      <div class="spacer"></div><div class="muted">${fmt(k.cantidad)} acciones × $${fmt(k.precio)} · disponibles ${fmt(k.disponible)}</div></div>`;
    if (k.total) h += `<div class="letras">${esc(Minuta.pesos(k.total))}</div>`;
    if (o.serie === 'C' && k.total) {
      const base = o.forma_pago === 'contado' ? k.total : k.pie;
      const medio = o.forma_pago === 'contado' ? o.pago_medio : o.pie_medio;
      if (medio === 'tarjeta' && base) h += `<div style="margin-top:6px">Con tarjeta de crédito se cobran <b>$${fmt(k.conRecargo(base))}</b> (recargo ${esc(String(A.c_recargo_tarjeta).replace('.', ','))}% de cargo del comprador; no es capital).</div>`;
    }
    if (o.forma_pago === 'parcial' && k.total) {
      h += `<div style="margin-top:6px">Saldo a plazo: <b>$${fmt(k.saldo)}</b>`;
      if (k.plan) {
        h += k.plan.n === 1 ? ` en una cuota el ${Minuta.fechaCorta(o.cuota_primera)}.`
          : ` en ${k.plan.n} cuotas ${o.periodicidad} de <b>$${fmt(k.plan.base)}</b>${k.plan.ultimaMonto !== k.plan.base ? ` (la última de $${fmt(k.plan.ultimaMonto)})` : ''}; última el <b>${Minuta.fechaCorta(k.plan.ultima)}</b>.`;
      }
      h += '</div>';
    }
    return h + '</div>';
  }

  function pasoOperacion() {
    const o = S.operacion, A = SES.ajustes;
    if (o.serie === 'B' && !o.tenencia_vendedor) o.tenencia_vendedor = String(calc().disponible);
    let h = `<h2>Acciones, precio y pago</h2><div class="grid">
      ${F('operacion.cantidad', 'Cantidad de acciones', { cls: 'c4', num: 1, ph: '1.000' })}
      ${F('operacion.precio', 'Precio por acción ($)', { cls: 'c4', num: 1, ph: o.serie === 'C' ? `mínimo ${fmt(A.c_precio_minimo)}` : '' })}
      ${F('operacion.fecha_contrato', 'Fecha del contrato', { cls: 'c4', type: 'date', rr: 1 })}
    </div>${bloqueCalc()}`;
    if (o.serie === 'C') {
      h += `<div class="grid">
        ${F('operacion.ronda', 'Ronda', { cls: 'c4', opts: [['', 'Sin indicar ronda'], 'C-1', 'C-2', 'C-3'] })}
        <div class="c8">${chk('operacion.acuerdo_dir', 'El precio fue fijado por acuerdo de directorio')}</div>
        ${o.acuerdo_dir ? F('operacion.acuerdo_fecha', 'Fecha de la sesión de directorio', { cls: 'c4', type: 'date' }) : ''}
      </div>`;
    } else {
      h += `<div class="grid">${F('operacion.tenencia_vendedor', 'Acciones Serie B de que es dueño el vendedor antes de esta venta', { cls: 'c6', num: 1, hint: 'Calculado con las ventas Serie B ya generadas o firmadas. Corrija si hubo movimientos fuera de la plataforma.' })}
        ${F('operacion.agente', 'Agente comercial', { cls: 'c6', small: '(solo base de datos)' })}</div>`;
    }
    h += `<hr class="sep"><div class="subt">Forma de pago</div>${seg('operacion.forma_pago', [['contado', 'Al contado'], ['parcial', 'Pago parcial y saldo en cuotas']])}`;
    const medios = [['transferencia', 'Transferencia a Cuenta Vista Mercado Pago'], ['tarjeta', 'Tarjeta de crédito (link de pago)']];
    if (o.forma_pago === 'contado') {
      h += `<div class="grid">${F('operacion.pago_fecha', 'Fecha en que se recibió el pago', { cls: 'c4', type: 'date', hint: 'El contrato declara el precio recibido: debe estar pagado al firmar.' })}
        ${o.serie === 'C' ? F('operacion.pago_medio', 'Medio de pago', { cls: 'c8', opts: medios, rr: 1 }) : `<div class="c8 hint oro" style="margin-top:24px">Transferencia a la ${esc(A.b_tipo_cuenta)} N° ${esc(A.b_cuenta)} del ${esc(A.b_banco)}.</div>`}</div>`;
    } else {
      h += `<div class="grid">
        ${F('operacion.pie_monto', 'Pago inicial ($)', { cls: 'c4', num: 1 })}
        ${F('operacion.pie_fecha', 'Fecha del pago inicial', { cls: 'c4', type: 'date' })}
        ${o.serie === 'C' ? F('operacion.pie_medio', 'Medio del pago inicial', { cls: 'c4', opts: medios, rr: 1 }) : '<div class="c4"></div>'}
        ${F('operacion.cuotas_n', 'N° de cuotas del saldo', { cls: 'c4', num: 1 })}
        ${F('operacion.periodicidad', 'Periodicidad', { cls: 'c4', opts: [['mensuales', 'Mensuales'], ['trimestrales', 'Trimestrales']], rr: 1 })}
        ${F('operacion.cuota_primera', 'Vencimiento primera cuota', { cls: 'c4', type: 'date', rr: 1 })}
        ${o.serie === 'B' ? `<div class="c12">${chk('operacion.reajuste_uf', 'Saldo reajustable en UF')}</div>` : '<div class="c12 hint">El saldo se reajusta en UF y, mientras no esté pagado, rige el Art. Octavo (sin voto) y el Art. Noveno en caso de mora.</div>'}
      </div>`;
    }
    return h;
  }

  function pasoDeclaraciones() {
    const o = S.operacion;
    const testigos = o.serie === 'B' || o.testigos_incluir;
    let h = `<h2>Declaraciones y cierre</h2><div class="grid">
      ${F('operacion.origen_fondos', 'Origen de los fondos', { cls: 'c12', type: 'textarea', ph: 'ahorros generados en su actividad profesional como médico cirujano', hint: 'Se inserta en la cláusula de origen de fondos (Ley 20.393 / 19.913): "los fondos con que paga el precio provienen de …"' })}
    </div><div class="subt">Inversión extranjera</div>
    ${seg('operacion.inversion_ext', [['A', 'Recursos obtenidos y mantenidos en Chile'], ['B', 'Recursos provenientes del exterior (Cap. XIV CNCI)']])}
    <div class="grid">${F('operacion.dias_registro', 'Días hábiles para inscribir en el Registro de Accionistas', { cls: 'c6', num: 1 })}
      ${o.serie === 'C' ? F('operacion.agente', 'Agente comercial', { cls: 'c6', small: '(solo base de datos)' }) : ''}</div>
    <div class="subt">Testigos</div>`;
    if (o.serie === 'B') h += '<p class="hint">El traspaso de acciones se firma ante dos testigos mayores de edad (art. 37 Ley 18.046 y su Reglamento). Firmarán también en FirmaYa.</p>';
    else h += `<div class="grid">${chk('operacion.testigos_incluir', 'Incluir dos testigos (opcional en Serie C)')}</div>`;
    if (testigos) {
      h += '<div class="grid">' + o.testigos.map((t, i) => F(`operacion.testigos.${i}.nombre`, `Testigo ${i + 1} — nombre completo`, { cls: 'c8' }) + F(`operacion.testigos.${i}.rut`, 'RUN', { cls: 'c4', rut: 1 })).join('') + '</div>';
    }
    h += `<div class="grid">${F('operacion.notas', 'Notas internas', { cls: 'c12', type: 'textarea', small: '(no van al contrato)' })}</div>`;
    return h;
  }

  function pasoRevision() {
    const E = S._errs, o = S.operacion, c = S.comprador, k = calc();
    let h = '<h2>Revisión y generación</h2>';
    if (E.length) {
      h += `<p class="alert err">Hay ${E.length} ${E.length === 1 ? 'dato pendiente' : 'datos pendientes'}. Haga clic en cada uno para ir al campo.</p>
        <ul class="errores">${E.map(e => `<li data-ir="${e.paso}" data-campo="${e.campo}"><b>${PASOS[e.paso]}:</b> ${esc(e.msg)}</li>`).join('')}</ul>`;
    } else {
      h += '<p class="alert ok">Todos los datos están completos y validados.</p>';
    }
    const fila = (a, b) => `<tr><td>${a}</td><td>${b}</td></tr>`;
    h += `<table class="resumen">
      ${fila('Operación', o.serie === 'C' ? `Suscripción y compraventa Serie C — vende ${esc(SES.ajustes.odo_razon)}` : o.serie === 'B' ? `Compraventa y cesión Serie B — vende ${esc(SES.ajustes.iv_razon)}` : '—')}
      ${fila('Comprador', `${esc(c.nombre || '—')} · ${esc(c.documento || '')}${c.tipo === 'juridica' ? ` · rep. ${esc(c.rep_nombre)}` : ''}`)}
      ${fila('Correo', esc(c.email))}
      ${fila('Acciones', `${fmt(k.cantidad)} × $${fmt(k.precio)} = <b>$${fmt(k.total)}</b>`)}
      ${fila('Pago', o.forma_pago === 'contado' ? `Al contado el ${Minuta.fechaCorta(o.pago_fecha)}` : `Pie $${fmt(k.pie)} y saldo $${fmt(k.saldo)}${k.plan ? ` en ${k.plan.n} cuota(s) ${o.periodicidad} hasta el ${Minuta.fechaCorta(k.plan.ultima)}` : ''}`)}
      ${fila('Fecha del contrato', Minuta.fechaCorta(o.fecha_contrato))}
      ${S.folio ? fila('Folio', `${esc(S.folio)} · versión ${S.version || 0}`) : ''}
    </table>
    <div class="row end" style="margin-top:16px">
      ${S.id && S.version ? '<button class="btn" id="verUltimo">Ver último PDF</button>' : ''}
      <button class="btn oro" id="generar" ${E.length ? 'disabled' : ''}>${S.version ? 'Regenerar PDF (nueva versión)' : 'Validar y generar PDF'}</button>
    </div>
    <p class="hint" style="margin-top:10px">Al generar, el comprador queda registrado en la base, la operación recibe folio y el PDF se archiva. Luego podrá verlo, descargarlo para subir a FirmaYa y, una vez firmado, marcarlo como «firmada» en Operaciones.</p>`;
    return h;
  }

  function datosContrato() {
    const k = calc();
    const o = JSON.parse(JSON.stringify(S.operacion));
    o.cantidad = k.cantidad; o.precio = k.precio; o.total = k.total;
    o.pie_monto = k.pie; o.cuotas_n = num(o.cuotas_n); o.tenencia_vendedor = num(o.tenencia_vendedor); o.dias_registro = num(o.dias_registro);
    o.cuota_ultima = k.plan ? k.plan.ultima : '';
    const c = JSON.parse(JSON.stringify(S.comprador));
    c.nombre = c.nombre.trim().replace(/\s+/g, ' ');
    c.email = c.email.trim().toLowerCase();
    if (c.tipo === 'juridica' || c.doc_tipo === 'rut') c.documento = rutFormato(c.documento);
    if (c.tipo === 'juridica') { c.rep_documento = rutFormato(c.rep_documento); c.doc_tipo = 'rut'; }
    c.estado_civil_texto = c.tipo === 'natural' ? Minuta.estadoCivilTexto(c.estado_civil, c.regimen, c.trat) : '';
    c.rep_documento = c.rep_documento || '';
    o.testigos = (o.testigos || []).map(t => ({ nombre: t.nombre.trim(), rut: t.rut ? rutFormato(t.rut) : '' }));
    return { comprador: c, operacion: o };
  }

  async function generar(btn) {
    S.mostrarErrores = true;
    S._errs = validar();
    if (S._errs.length) { renderWizard(); return; }
    btn.disabled = true; btn.textContent = 'Generando…';
    try {
      const d = datosContrato();
      const r = await api('guardar_operacion', { method: 'POST', body: { id: S.id, comprador: d.comprador, operacion: d.operacion } });
      S.id = r.id; S.folio = r.folio;
      const version = (S.version || 0) + 1;
      const pdf = Minuta.generarPdf(d, SES.ajustes, { folio: r.folio, version });
      // Un solo renderizado: el PDF que se archiva es idéntico (mismo SHA-256) al que se ve y descarga
      const bytes = await new Promise(res => pdf.getBuffer(res));
      const blob = new Blob([bytes], { type: 'application/pdf' });
      const b64 = await new Promise(res => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1]); fr.readAsDataURL(blob); });
      const up = await api('subir_pdf', { method: 'POST', body: { id: S.id, pdf: b64 } });
      S.version = up.version; S.estadoOriginal = 'generada'; S.serieOriginal = d.operacion.serie; S.cantidadOriginal = d.operacion.cantidad;
      SES.cupos = up.cupos;
      renderWizard();
      visor(blob, `${r.folio}-v${up.version}.pdf`, `${r.folio} · versión ${up.version}`);
      toast('Minuta generada y archivada');
    } catch (e) {
      toast(e.message, true);
      renderWizard();
    }
  }

  function visor(blob, nombre, titulo) {
    const url = URL.createObjectURL(blob);
    const m = document.createElement('div');
    m.className = 'modal visor';
    m.innerHTML = `<div class="box"><div class="bar"><span class="tt">${esc(titulo)}</span>
      <a class="btn oro small" href="${url}" download="${esc(nombre)}">Descargar para firma</a>
      <a class="btn small" style="color:var(--crema)" href="${url}" target="_blank" rel="noopener">Abrir en pestaña</a>
      <button class="btn small" style="color:var(--crema)" data-x>Cerrar</button></div>
      <iframe src="${url}#view=FitH" title="Minuta PDF"></iframe></div>`;
    document.body.appendChild(m);
    $('[data-x]', m).onclick = () => { m.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); };
  }

  async function verPdfArchivado(id, nombre, titulo) {
    try {
      const r = await fetch(`api.php?a=pdf&id=${id}`, { credentials: 'same-origin' });
      if (!r.ok) throw new Error('PDF no disponible');
      visor(await r.blob(), nombre, titulo);
    } catch (e) { toast(e.message, true); }
  }

  // Búsqueda de compradores registrados
  let tBusca = null;
  async function buscarCompradores(q) {
    const box = $('#resComp');
    if (!box) return;
    if (q.trim().length < 3) { box.innerHTML = ''; return; }
    try {
      const r = await api('compradores', { params: '&q=' + encodeURIComponent(q) });
      box.innerHTML = r.compradores.length
        ? `<div class="tabla-wrap"><table class="t">${r.compradores.slice(0, 8).map(c => `<tr><td>${esc(c.nombre)}</td><td>${esc(c.documento)}</td><td>${esc(c.email)}</td><td class="num"><button class="btn small" data-cargar="${c.id}">Usar</button></td></tr>`).join('')}</table></div>`
        : '<p class="hint">Sin coincidencias: complete los datos como comprador nuevo.</p>';
    } catch (e) { box.innerHTML = ''; }
  }
  async function cargarComprador(id) {
    const r = await api('comprador', { params: '&id=' + id });
    S.comprador = Object.assign(nuevoEstado().comprador, r.comprador.datos || {});
    toast('Datos del comprador cargados');
    renderWizard();
  }
  async function detectarRut() {
    const c = S.comprador;
    if (!(c.tipo === 'juridica' || c.doc_tipo === 'rut') || !rutValido(c.documento)) return;
    try {
      const r = await api('compradores', { params: '&q=' + encodeURIComponent(rutLimpio(c.documento)) });
      const m = r.compradores.find(x => rutLimpio(x.documento) === rutLimpio(c.documento));
      if (!m) return;
      if (!c.nombre || !c.email) await cargarComprador(m.id);
      else {
        const box = $('#resComp');
        if (box) box.innerHTML = `<p class="alert warn">Este RUT ya está registrado como ${esc(m.nombre)}. <button class="btn small" data-cargar="${m.id}">Cargar datos registrados</button></p>`;
      }
    } catch (e) { /* silencioso */ }
  }

  // Eventos del asistente (delegados)
  APP.addEventListener('input', e => {
    const el = e.target;
    if (el.id === 'buscaComp') { clearTimeout(tBusca); tBusca = setTimeout(() => buscarCompradores(el.value), 280); return; }
    if (!S || !el.dataset.p || el.type === 'radio' || el.type === 'checkbox' || el.tagName === 'SELECT') return;
    let v = el.value;
    if (el.dataset.num !== undefined) {
      const n = v.replace(/[^\d]/g, '');
      v = n; el.value = n ? fmt(+n) : '';
    }
    setP(S, el.dataset.p, v);
    el.classList.remove('invalido');
    const cb = $('#calc');
    if (cb && /^operacion\.(cantidad|precio|pie_monto|cuotas_n)$/.test(el.dataset.p)) cb.outerHTML = bloqueCalc();
    guardarWip();
  });
  APP.addEventListener('change', e => {
    const el = e.target;
    if (!S || !el.dataset.p) return;
    let v;
    if (el.type === 'checkbox') v = el.checked;
    else if (el.dataset.num !== undefined) v = el.value.replace(/[^\d]/g, '');
    else v = el.value;
    if (el.dataset.rut !== undefined && v) { v = rutFormato(v); el.value = v; }
    const prev = getP(S, el.dataset.p);
    setP(S, el.dataset.p, v);
    // Concordancia de nacionalidad con el tratamiento
    if (el.dataset.p === 'comprador.trat' || el.dataset.p === 'comprador.rep_trat') {
      const k = el.dataset.p === 'comprador.trat' ? 'nacionalidad' : 'rep_nacionalidad';
      if (S.comprador[k] === 'chileno' && v === 'doña') S.comprador[k] = 'chilena';
      if (S.comprador[k] === 'chilena' && v === 'don') S.comprador[k] = 'chileno';
    }
    if (el.dataset.p === 'comprador.tipo' && prev !== v) S.comprador.documento = '';
    if (el.dataset.p === 'comprador.documento' || el.dataset.p === 'comprador.rep_documento') detectarRut();
    if (el.dataset.rr !== undefined || el.type === 'radio' || el.type === 'checkbox' || el.tagName === 'SELECT') {
      const y = window.scrollY; renderWizard(); window.scrollTo(0, y);
    } else guardarWip();
  });
  APP.addEventListener('click', async e => {
    const t = e.target.closest('button, li');
    if (!t || !S || (location.hash.replace(/^#\//, '') || 'nueva') !== 'nueva') return;
    if (t.dataset.serie) {
      if (S.operacion.serie && S.operacion.serie !== t.dataset.serie) S.operacion.tenencia_vendedor = '';
      S.operacion.serie = t.dataset.serie; S.paso = 1; renderWizard(); window.scrollTo(0, 0); return;
    }
    if (t.dataset.paso !== undefined) { S.paso = +t.dataset.paso; renderWizard(); return; }
    if (t.dataset.cargar) { await cargarComprador(t.dataset.cargar); return; }
    if (t.dataset.ir !== undefined || t.dataset.campo) {
      if (t.dataset.ir !== undefined) { S.paso = +t.dataset.ir; S.mostrarErrores = true; renderWizard(); }
      const f = t.dataset.campo && $(`[data-p="${t.dataset.campo}"]`);
      if (f) { f.scrollIntoView({ block: 'center' }); f.focus(); }
      return;
    }
    if (t.id === 'sig') {
      const errs = validar().filter(x => x.paso === S.paso);
      if (errs.length) S.mostrarErrores = true;
      S.paso = Math.min(4, S.paso + 1); renderWizard(); window.scrollTo(0, 0); return;
    }
    if (t.id === 'ant') { S.paso = Math.max(0, S.paso - 1); renderWizard(); window.scrollTo(0, 0); return; }
    if (t.id === 'generar') { generar(t); return; }
    if (t.id === 'verUltimo') { verPdfArchivado(S.id, `${S.folio}-v${S.version}.pdf`, `${S.folio} · versión ${S.version}`); return; }
    if (t.id === 'descartar') {
      if (!S.id && !(await confirmar('Descartar formulario', 'Se perderán los datos ingresados que aún no se han generado.', { ok: 'Descartar', peligro: true }))) return;
      borrarWip(); S = nuevoEstado(); renderWizard();
    }
  });

  // ── Vista: Operaciones ─────────────────────────────────────────────────
  const filtrosOp = { serie: '', estado: '', q: '' };
  async function vistaOperaciones() {
    APP.innerHTML = '<p class="muted">Cargando operaciones…</p>';
    const p = `&serie=${filtrosOp.serie}&estado=${filtrosOp.estado}&q=${encodeURIComponent(filtrosOp.q)}`;
    let r;
    try { r = await api('operaciones', { params: p }); } catch (e) { APP.innerHTML = `<p class="alert err">${esc(e.message)}</p>`; return; }
    SES.cupos = r.cupos;
    const ops = r.operaciones;
    const cnt = est => ops.filter(o => o.estado === est).length;
    const master = SES.usuario.rol === 'master';
    APP.innerHTML = `<div class="row" style="margin-bottom:12px"><h1 style="margin:0">Operaciones</h1><span class="spacer"></span><a class="btn primary" href="#/nueva" id="opNueva">+ Nueva minuta</a></div>
      <div class="kpis">
        <div class="kpi"><b>${fmt(r.cupos.C.disponible)}</b><span>Serie C disponibles (de ${fmt(r.cupos.C.total)})</span></div>
        <div class="kpi"><b>${fmt(r.cupos.B.disponible)}</b><span>Serie B en poder del vendedor</span></div>
        <div class="kpi"><b>${cnt('generada')}</b><span>Generadas, pendientes de firma${filtrosOp.estado || filtrosOp.serie || filtrosOp.q ? ' (filtro)' : ''}</span></div>
        <div class="kpi"><b>${cnt('firmada')}</b><span>Firmadas${filtrosOp.estado || filtrosOp.serie || filtrosOp.q ? ' (filtro)' : ''}</span></div>
      </div>
      <div class="card"><div class="grid">
        <label class="c3">Serie<select id="fSerie"><option value="">Todas</option><option ${filtrosOp.serie === 'C' ? 'selected' : ''}>C</option><option ${filtrosOp.serie === 'B' ? 'selected' : ''}>B</option></select></label>
        <label class="c3">Estado<select id="fEstado"><option value="">Todos</option>${['borrador', 'generada', 'firmada', 'anulada'].map(x => `<option ${filtrosOp.estado === x ? 'selected' : ''}>${x}</option>`).join('')}</select></label>
        <label class="c6">Buscar<input id="fQ" type="search" value="${esc(filtrosOp.q)}" placeholder="Folio, comprador o RUT"></label>
      </div>
      <div class="tabla-wrap"><table class="t"><thead><tr><th>Folio</th><th>Fecha</th><th>Comprador</th><th class="num">Acciones</th><th class="num">Precio</th><th class="num">Total</th><th>Pago</th><th>Estado</th><th></th></tr></thead><tbody>
      ${ops.length ? ops.map(o => `<tr>
        <td><b>${esc(o.folio)}</b><br><small>v${o.version} · ${esc(o.creado_por || '')}</small></td>
        <td>${Minuta.fechaCorta(o.fecha_contrato)}</td>
        <td>${esc(o.comprador)}<br><small>${esc(o.documento)}</small></td>
        <td class="num">${fmt(o.cantidad)}</td><td class="num">$${fmt(o.precio_unitario)}</td><td class="num"><b>$${fmt(o.total)}</b></td>
        <td>${o.forma_pago === 'contado' ? 'Contado' : 'Parcial'}</td>
        <td><span class="pill ${o.estado}">${o.estado}</span></td>
        <td><div class="acciones">
          ${o.version > 0 ? `<button class="btn small" data-ver="${o.id}" data-n="${esc(o.folio)}-v${o.version}.pdf">Ver</button><a class="btn small" href="api.php?a=pdf&descargar=1&id=${o.id}">Descargar</a>` : ''}
          ${['borrador', 'generada'].includes(o.estado) ? `<button class="btn small" data-editar="${o.id}">Editar</button>` : ''}
          <button class="btn small" data-duplicar="${o.id}">Duplicar</button>
          ${o.estado === 'generada' ? `<button class="btn small" data-firmada="${o.id}">Firmada</button>` : ''}
          ${o.estado !== 'anulada' && (o.estado !== 'firmada' || master) ? `<button class="btn small peligro" data-anular="${o.id}">Anular</button>` : ''}
        </div></td></tr>`).join('') : '<tr><td colspan="9" class="muted">Sin operaciones.</td></tr>'}
      </tbody></table></div></div>`;
    $('#fSerie').onchange = e => { filtrosOp.serie = e.target.value; vistaOperaciones(); };
    $('#fEstado').onchange = e => { filtrosOp.estado = e.target.value; vistaOperaciones(); };
    let tq; $('#fQ').oninput = e => { clearTimeout(tq); tq = setTimeout(() => { filtrosOp.q = e.target.value; vistaOperaciones().then(() => { const f = $('#fQ'); f.focus(); f.setSelectionRange(f.value.length, f.value.length); }); }, 350); };
    $('#opNueva').onclick = () => { borrarWip(); S = null; };
    APP.querySelectorAll('[data-ver]').forEach(b => b.onclick = () => verPdfArchivado(b.dataset.ver, b.dataset.n, b.dataset.n.replace('.pdf', '')));
    APP.querySelectorAll('[data-editar]').forEach(b => b.onclick = () => abrirOperacion(b.dataset.editar, false));
    APP.querySelectorAll('[data-duplicar]').forEach(b => b.onclick = () => abrirOperacion(b.dataset.duplicar, true));
    APP.querySelectorAll('[data-firmada]').forEach(b => b.onclick = async () => {
      if (!(await confirmar('Marcar como firmada', 'Confirme que el contrato fue firmado por todas las partes en FirmaYa. Después no podrá editarse.', { ok: 'Marcar firmada' }))) return;
      try { await api('estado', { method: 'POST', body: { id: +b.dataset.firmada, estado: 'firmada' } }); toast('Operación marcada como firmada'); vistaOperaciones(); } catch (e) { toast(e.message, true); }
    });
    APP.querySelectorAll('[data-anular]').forEach(b => b.onclick = async () => {
      const motivo = await confirmar('Anular operación', 'La operación queda anulada y sus acciones vuelven a estar disponibles. El PDF archivado se conserva.', { ok: 'Anular', peligro: true, motivo: true });
      if (!motivo) return;
      try { await api('estado', { method: 'POST', body: { id: +b.dataset.anular, estado: 'anulada', motivo } }); toast('Operación anulada'); vistaOperaciones(); } catch (e) { toast(e.message, true); }
    });
  }

  async function abrirOperacion(id, duplicar) {
    try {
      const r = await api('operacion', { params: '&id=' + id });
      const op = r.operacion, base = nuevoEstado();
      S = Object.assign(base, {
        comprador: Object.assign(base.comprador, op.datos.comprador),
        operacion: Object.assign(base.operacion, op.datos.operacion),
        paso: 1,
      });
      ['cantidad', 'precio', 'pie_monto', 'tenencia_vendedor'].forEach(k => { if (S.operacion[k] !== '' && S.operacion[k] != null) S.operacion[k] = String(S.operacion[k]); });
      if (duplicar) {
        Object.assign(S.operacion, { fecha_contrato: hoy(), pago_fecha: hoy(), pie_fecha: hoy(), cuota_primera: '', tenencia_vendedor: '' });
      } else {
        Object.assign(S, { id: op.id, folio: op.folio, version: +op.version, estadoOriginal: op.estado, serieOriginal: op.serie, cantidadOriginal: op.cantidad });
      }
      location.hash = '#/nueva';
      if (duplicar) toast('Operación duplicada: revise fechas y datos');
    } catch (e) { toast(e.message, true); }
  }

  // ── Vista: Compradores ─────────────────────────────────────────────────
  async function vistaCompradores(q = '') {
    let r;
    try { r = await api('compradores', { params: '&q=' + encodeURIComponent(q) }); } catch (e) { APP.innerHTML = `<p class="alert err">${esc(e.message)}</p>`; return; }
    const master = SES.usuario.rol === 'master';
    APP.innerHTML = `<div class="row" style="margin-bottom:12px"><h1 style="margin:0">Compradores</h1><span class="spacer"></span>
        ${master ? '<a class="btn" href="api.php?a=exportar_compradores">Exportar CSV</a>' : ''}</div>
      <div class="card"><label>Buscar<input id="cQ" type="search" value="${esc(q)}" placeholder="Nombre, RUT o correo"></label>
      <div class="tabla-wrap"><table class="t"><thead><tr><th>Nombre / razón social</th><th>Documento</th><th>Tipo</th><th>Correo</th><th>Teléfono</th><th>Comuna</th><th class="num">Operaciones</th><th></th></tr></thead><tbody>
      ${r.compradores.length ? r.compradores.map(c => `<tr><td><b>${esc(c.nombre)}</b></td><td>${esc(c.documento)}</td><td>${c.tipo === 'natural' ? 'Natural' : 'Jurídica'}</td>
        <td>${esc(c.email)}</td><td>${esc(c.telefono || '')}</td><td>${esc(c.comuna || '')}</td><td class="num">${c.operaciones}</td>
        <td><div class="acciones"><button class="btn small" data-min="${c.id}">Nueva minuta</button><button class="btn small" data-ops="${esc(c.documento)}">Operaciones</button></div></td></tr>`).join('')
        : '<tr><td colspan="8" class="muted">Sin compradores registrados. Se agregan automáticamente al generar una minuta.</td></tr>'}
      </tbody></table></div></div>`;
    let t; $('#cQ').oninput = e => { clearTimeout(t); t = setTimeout(() => vistaCompradores(e.target.value).then(() => { const f = $('#cQ'); f.focus(); f.setSelectionRange(f.value.length, f.value.length); }), 350); };
    APP.querySelectorAll('[data-min]').forEach(b => b.onclick = async () => {
      const rr = await api('comprador', { params: '&id=' + b.dataset.min });
      S = nuevoEstado();
      S.comprador = Object.assign(S.comprador, rr.comprador.datos || {});
      S.paso = 0;
      location.hash = '#/nueva';
      toast('Elija la serie; los datos del comprador ya están cargados');
    });
    APP.querySelectorAll('[data-ops]').forEach(b => b.onclick = () => { filtrosOp.q = b.dataset.ops; filtrosOp.serie = ''; filtrosOp.estado = ''; location.hash = '#/operaciones'; });
  }

  // ── Vista: Ajustes (máster) ────────────────────────────────────────────
  const AJ = [
    ['ODO — vendedora Serie C', [
      ['odo_razon', 'Razón social', 'c8'], ['odo_rut', 'RUT', 'c4'], ['odo_fantasia', 'Nombre de fantasía', 'c4'], ['odo_giro', 'Giro', 'c8'],
      ['odo_domicilio', 'Domicilio (texto completo)', 'c12', 'ta'],
      ['odo_rep_trat', 'Tratamiento', 'c3'], ['odo_rep_nombre', 'Representante (MAYÚSCULAS)', 'c6'], ['odo_rep_run', 'RUN', 'c3'],
      ['odo_rep_nacionalidad', 'Nacionalidad', 'c3'], ['odo_rep_estado_civil', 'Estado civil', 'c3'], ['odo_rep_profesion', 'Profesión', 'c3'], ['odo_rep_cargo', 'Cargo', 'c3'],
      ['odo_rep_personeria', 'Personería del representante («consta en …»)', 'c12', 'ta'],
      ['odo_antecedentes', 'Antecedentes de constitución (cláusula Primera)', 'c12', 'ta'],
    ]],
    ['Serie C — pago y límites', [
      ['c_cuenta_mp', 'Cuenta Vista Mercado Pago N°', 'c4'], ['c_link_pago', 'Link de pago', 'c8'], ['c_recargo_tarjeta', 'Recargo tarjeta (%)', 'c4'], ['c_correo_pagos', 'Correo comprobantes', 'c8'],
      ['c_total_serie', 'Total acciones Serie C', 'c4'], ['c_precio_minimo', 'Precio mínimo por acción ($)', 'c4'], ['c_plazo_maximo', 'Plazo máximo de pago (AAAA-MM-DD)', 'c4'],
    ]],
    ['IVELSA — vendedor Serie B', [
      ['iv_razon', 'Razón social', 'c8'], ['iv_rut', 'RUT', 'c4'], ['iv_giro', 'Giro', 'c12'], ['iv_domicilio', 'Domicilio (texto completo)', 'c12', 'ta'],
      ['iv_rep_trat', 'Tratamiento', 'c3'], ['iv_rep_nombre', 'Representante (MAYÚSCULAS)', 'c6'], ['iv_rep_run', 'RUN', 'c3'],
      ['iv_rep_nacionalidad', 'Nacionalidad', 'c4'], ['iv_rep_estado_civil', 'Estado civil', 'c4'], ['iv_rep_profesion', 'Profesión', 'c4'],
      ['iv_pers_fecha', 'Personería: fecha del certificado de poderes RES', 'c4', 'date'], ['iv_pers_cve', 'Personería: código de verificación electrónica (CVE)', 'c8'],
      ['b_banco', 'Banco', 'c4'], ['b_tipo_cuenta', 'Tipo de cuenta', 'c4'], ['b_cuenta', 'N° de cuenta', 'c4'], ['b_correo_pagos', 'Correo comprobantes', 'c6'],
      ['b_tenencia_inicial', 'Acciones Serie B de IVELSA al iniciar la plataforma', 'c6'],
    ]],
    ['Comunes', [
      ['abogado_nombre', 'Abogado con poder especial (con «don/doña»)', 'c8'], ['abogado_run', 'RUN del abogado', 'c4'],
      ['ciudad_firma', 'Ciudad del contrato', 'c4'], ['dias_registro', 'Días hábiles para inscribir (por defecto)', 'c4'], ['plataforma_firma', 'Plataforma de firma', 'c4'],
    ]],
  ];
  const AJ_LABEL = {}; AJ.forEach(([g, fs]) => fs.forEach(([k, l]) => { AJ_LABEL[k] = g.split(' ')[0] + ': ' + l.replace(/ \(.*\)$/, '').replace(/ «.*»$/, ''); }));

  function vistaAjustes() {
    const A = SES.ajustes;
    APP.innerHTML = `<h1>Ajustes</h1><p class="muted">Datos de los vendedores que se insertan en los contratos. Los campos en amarillo están pendientes.</p>
      <form id="fAj">${AJ.map(([g, fs]) => `<div class="card"><h2>${esc(g)}</h2><div class="grid">${fs.map(([k, l, cls, ta]) => {
        const pend = /COMPLETAR/i.test(A[k] || '') || !String(A[k] || '').trim();
        return `<label class="${cls}">${esc(l)}${ta === 'ta' ? `<textarea name="${k}" class="${pend ? 'completar' : ''}">${esc(A[k])}</textarea>` : `<input name="${k}" type="${ta === 'date' ? 'date' : 'text'}" value="${esc(A[k])}" class="${pend ? 'completar' : ''}">`}</label>`;
      }).join('')}</div></div>`).join('')}
      <div class="row end"><button class="btn primary" type="submit">Guardar ajustes</button></div></form>`;
    $('#fAj').onsubmit = async e => {
      e.preventDefault();
      const body = {}; new FormData(e.target).forEach((v, k) => { body[k] = v; });
      try { const r = await api('ajustes', { method: 'POST', body }); SES.ajustes = r.ajustes; SES.cupos = r.cupos; toast('Ajustes guardados'); vistaAjustes(); } catch (er) { toast(er.message, true); }
    };
  }

  // ── Vista: Usuarios (máster) ───────────────────────────────────────────
  async function vistaUsuarios() {
    let r;
    try { r = await api('usuarios'); } catch (e) { APP.innerHTML = `<p class="alert err">${esc(e.message)}</p>`; return; }
    APP.innerHTML = `<h1>Usuarios</h1>
      <div class="card"><h2>Crear usuario</h2><form id="fU" class="grid">
        <label class="c4">Correo<input name="email" type="email" required></label>
        <label class="c4">Nombre<input name="nombre" required></label>
        <label class="c4">Perfil<select name="rol"><option value="usuario">Usuario (genera minutas)</option><option value="master">Máster</option></select></label>
        <label class="c6">Clave temporal <small>(mín. 6; se exigirá cambiarla al primer ingreso)</small><input name="clave" required minlength="6"></label>
        <div class="c6" style="display:flex;align-items:flex-end;padding-bottom:12px"><button class="btn primary" type="submit">Crear usuario</button></div>
      </form></div>
      <div class="card"><div class="tabla-wrap"><table class="t"><thead><tr><th>Correo</th><th>Nombre</th><th>Perfil</th><th>Estado</th><th>Último ingreso</th><th></th></tr></thead><tbody>
      ${r.usuarios.map(u => `<tr><td>${esc(u.email)}</td><td>${esc(u.nombre)}</td><td>${u.rol === 'master' ? 'Máster' : 'Usuario'}</td>
        <td>${+u.activo ? (+u.debe_cambiar ? '<span class="pill generada">clave temporal</span>' : '<span class="pill firmada">activo</span>') : '<span class="pill anulada">inactivo</span>'}</td>
        <td>${esc(u.ultimo_ingreso || '—')}</td>
        <td><div class="acciones">${+u.id !== +SES.usuario.id ? `<button class="btn small" data-act="${u.id}" data-v="${+u.activo ? 0 : 1}">${+u.activo ? 'Desactivar' : 'Activar'}</button>` : ''}
          <button class="btn small" data-reset="${u.id}">Nueva clave temporal</button></div></td></tr>`).join('')}
      </tbody></table></div></div>`;
    $('#fU').onsubmit = async e => {
      e.preventDefault();
      const b = {}; new FormData(e.target).forEach((v, k) => { b[k] = v; });
      try { await api('usuario_crear', { method: 'POST', body: b }); toast('Usuario creado'); vistaUsuarios(); } catch (er) { toast(er.message, true); }
    };
    APP.querySelectorAll('[data-act]').forEach(b => b.onclick = async () => {
      try { await api('usuario_actualizar', { method: 'POST', body: { id: +b.dataset.act, activo: +b.dataset.v === 1 } }); vistaUsuarios(); } catch (e) { toast(e.message, true); }
    });
    APP.querySelectorAll('[data-reset]').forEach(b => b.onclick = () => {
      modal(`<h2>Nueva clave temporal</h2><label>Clave temporal (mín. 6)<input id="nc" minlength="6"></label><div class="row end"><button class="btn" data-x>Cancelar</button><button class="btn primary" data-ok>Guardar</button></div>`, (m, close) => {
        $('[data-x]', m).onclick = close;
        $('[data-ok]', m).onclick = async () => {
          try { await api('usuario_actualizar', { method: 'POST', body: { id: +b.dataset.reset, clave: $('#nc', m).value } }); close(); toast('Clave temporal asignada'); vistaUsuarios(); } catch (e) { toast(e.message, true); }
        };
      });
    });
  }

  async function vistaBitacora() {
    let r;
    try { r = await api('bitacora'); } catch (e) { APP.innerHTML = `<p class="alert err">${esc(e.message)}</p>`; return; }
    APP.innerHTML = `<h1>Bitácora</h1><div class="card"><div class="tabla-wrap"><table class="t"><thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Detalle</th><th>IP</th></tr></thead><tbody>
      ${r.bitacora.map(b => `<tr><td style="white-space:nowrap">${esc(b.creado_en)}</td><td>${esc(b.email || '—')}</td><td>${esc(b.accion)}</td><td><small>${esc(b.detalle || '')}</small></td><td>${esc(b.ip)}</td></tr>`).join('')}
      </tbody></table></div></div>`;
  }

  // ── Router ─────────────────────────────────────────────────────────────
  const RUTAS = { nueva: vistaNueva, operaciones: vistaOperaciones, compradores: () => vistaCompradores(''), ajustes: vistaAjustes, usuarios: vistaUsuarios, bitacora: vistaBitacora };
  function router() {
    const r = (location.hash.replace(/^#\//, '') || 'nueva').split('?')[0];
    const fn = RUTAS[r] || vistaNueva;
    if (['ajustes', 'usuarios', 'bitacora'].includes(r) && SES.usuario.rol !== 'master') { location.hash = '#/nueva'; return; }
    $$('#menu a').forEach(a => a.classList.toggle('on', a.dataset.r === r));
    window.scrollTo(0, 0);
    fn();
  }

  $('#usrBtn').onclick = e => { e.stopPropagation(); $('#usrDd').classList.toggle('show'); };
  document.addEventListener('click', () => $('#usrDd').classList.remove('show'));

  (async () => {
    try {
      SES = await api('sesion');
      window.addEventListener('hashchange', router);
      router();
    } catch (e) {
      APP.innerHTML = `<p class="alert err">${esc(e.message)}</p>`;
    }
  })();
})();
