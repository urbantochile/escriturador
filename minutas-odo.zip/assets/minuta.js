/*
 * Minutas ODO — redacción de los contratos y generación del PDF.
 * Serie C: suscripción y compraventa (vende ODO, colocación de primera emisión).
 * Serie B: compraventa y cesión (vende IVELSA, acciones ya pagadas).
 * Ambas como instrumento privado para firma electrónica (Ley 19.799).
 */
(function (global) {
  'use strict';

  // ── Números a letras ───────────────────────────────────────────────────
  const U = ['', 'uno', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve', 'diez',
    'once', 'doce', 'trece', 'catorce', 'quince', 'dieciséis', 'diecisiete', 'dieciocho', 'diecinueve',
    'veinte', 'veintiuno', 'veintidós', 'veintitrés', 'veinticuatro', 'veinticinco', 'veintiséis',
    'veintisiete', 'veintiocho', 'veintinueve'];
  const D = ['', '', 'veinte', 'treinta', 'cuarenta', 'cincuenta', 'sesenta', 'setenta', 'ochenta', 'noventa'];
  const C = ['', 'ciento', 'doscientos', 'trescientos', 'cuatrocientos', 'quinientos', 'seiscientos',
    'setecientos', 'ochocientos', 'novecientos'];

  // modo del "uno" final: 'masc' → uno, 'fem' → una, 'apoc' → un. femCentenas: doscientas…
  function trio(n, modo, femCentenas) {
    if (n === 0) return '';
    if (n === 100) return 'cien';
    const c = Math.floor(n / 100), r = n % 100;
    let cs = C[c];
    if (femCentenas && c > 1) cs = cs.replace(/ientos$/, 'ientas');
    let rs = '';
    if (r > 0 && r < 30) rs = U[r];
    else if (r >= 30) { const d = Math.floor(r / 10), u = r % 10; rs = D[d] + (u ? ' y ' + U[u] : ''); }
    if (/uno$/.test(rs)) {
      if (modo === 'fem') rs = rs.replace(/uno$/, 'una');
      else if (modo === 'apoc') rs = rs === 'veintiuno' ? 'veintiún' : rs.replace(/uno$/, 'un');
    }
    return [cs, rs].filter(Boolean).join(' ');
  }

  function letras(n, modo) {
    modo = modo || 'masc';
    n = Math.round(Number(n));
    if (!isFinite(n) || n < 0) return '';
    if (n === 0) return 'cero';
    const fem = modo === 'fem';
    const mm = Math.floor(n / 1e6), resto = n % 1e6, mi = Math.floor(resto / 1000), un = resto % 1000;
    const p = [];
    if (mm) p.push(mm === 1 ? 'un millón' : letras(mm, 'apoc') + ' millones');
    if (mi) p.push(mi === 1 ? 'mil' : trio(mi, 'apoc', fem) + ' mil');
    if (un) p.push(trio(un, modo, fem));
    return p.join(' ');
  }

  const fmt = n => Math.round(Number(n) || 0).toLocaleString('es-CL').replace(/,/g, '.');
  const MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

  function parseFecha(iso) { const [y, m, d] = String(iso).split('-').map(Number); return { y, m, d }; }
  function fechaLetras(iso) {
    if (!iso) return '';
    const { y, m, d } = parseFecha(iso);
    return `${d === 1 ? 'primero' : letras(d, 'masc')} de ${MESES[m - 1]} de ${letras(y, 'masc')}`;
  }
  function fechaCorta(iso) { if (!iso) return ''; const { y, m, d } = parseFecha(iso); return `${String(d).padStart(2, '0')}-${String(m).padStart(2, '0')}-${y}`; }
  function sumarMeses(iso, meses) {
    const { y, m, d } = parseFecha(iso);
    const t = new Date(Date.UTC(y, m - 1 + meses, 1));
    const ultimo = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate();
    t.setUTCDate(Math.min(d, ultimo));
    return t.toISOString().slice(0, 10);
  }

  const deSi = n => (n % 1e6 === 0 ? ' de' : '');
  function pesos(n) { return n === 1 ? 'un peso ($1)' : `${letras(n, 'apoc')}${deSi(n)} pesos ($${fmt(n)})`; }
  function acciones(n) { if (Number(n) === 1) return 'una (1) acción'; return n % 1e6 === 0 ? `${letras(n, 'fem')} (${fmt(n)}) de acciones` : `${letras(n, 'fem')} (${fmt(n)}) acciones`; }

  // ── Cálculo de cuotas ──────────────────────────────────────────────────
  function planCuotas(saldo, n, primera, periodicidad) {
    n = Math.max(1, parseInt(n, 10) || 1);
    const base = Math.floor(saldo / n);
    const ultimaMonto = saldo - base * (n - 1);
    const paso = periodicidad === 'trimestrales' ? 3 : 1;
    const ultima = primera ? sumarMeses(primera, paso * (n - 1)) : '';
    return { n, base, ultimaMonto, ultima, paso };
  }

  // ── Textos auxiliares ──────────────────────────────────────────────────
  const ORD = ['PRIMERO', 'SEGUNDO', 'TERCERO', 'CUARTO', 'QUINTO', 'SEXTO', 'SÉPTIMO', 'OCTAVO', 'NOVENO', 'DÉCIMO',
    'UNDÉCIMO', 'DUODÉCIMO', 'DÉCIMO TERCERO', 'DÉCIMO CUARTO', 'DÉCIMO QUINTO', 'DÉCIMO SEXTO', 'DÉCIMO SÉPTIMO',
    'DÉCIMO OCTAVO', 'DÉCIMO NOVENO', 'VIGÉSIMO'];

  const fem = t => t === 'doña';
  function ag(t, masc, femn) { return fem(t) ? femn : masc; }

  function estadoCivilTexto(ec, regimen, trat) {
    const f = fem(trat);
    switch (ec) {
      case 'soltero': return f ? 'soltera' : 'soltero';
      case 'divorciado': return f ? 'divorciada' : 'divorciado';
      case 'viudo': return f ? 'viuda' : 'viudo';
      case 'conviviente': return 'conviviente civil';
      case 'casado': {
        const base = f ? 'casada' : 'casado';
        const r = { sociedad: 'bajo el régimen de sociedad conyugal', separacion: 'con separación total de bienes', gananciales: 'bajo el régimen de participación en los gananciales' }[regimen];
        return r ? `${base} ${r}` : base;
      }
      default: return '';
    }
  }

  function domicilioTexto(dom, comuna, region) {
    if (region === 'Extranjero') return `${dom}, ${comuna}`;
    return `${dom}, comuna de ${comuna}, ${region}`;
  }

  function docTexto(docTipo, doc, nacionalidad) {
    return docTipo === 'pasaporte'
      ? `pasaporte número **${doc}**`
      : `cédula nacional de identidad número **${doc}**`;
  }

  function personeriaCompradorTexto(c) {
    if (c.pers_tipo === 'escritura') return `escritura pública de fecha ${fechaLetras(c.pers_fecha)}, otorgada en la Notaría de ${c.pers_notaria}${c.pers_repertorio ? ', repertorio número ' + c.pers_repertorio : ''}`;
    if (c.pers_tipo === 'res') return `certificado de poderes emitido por el Registro de Empresas y Sociedades con fecha ${fechaLetras(c.pers_fecha)}, código de verificación electrónica (CVE) ${c.pers_cve}`;
    return c.pers_texto || '';
  }

  function compradorComparecencia(c) {
    if (c.tipo === 'juridica') {
      return `la sociedad **${up(c.nombre)}**, Rol Único Tributario número **${c.documento}**, del giro ${c.giro}, domiciliada en ${domicilioTexto(c.domicilio, c.comuna, c.region)}, correo electrónico ${c.email}, representada según se acreditará por ${c.rep_trat} **${c.rep_nombre.toUpperCase()}**, ${c.rep_nacionalidad}, ${estadoCivilTexto(c.rep_estado_civil, c.rep_regimen, c.rep_trat)}, ${c.rep_profesion}, cédula nacional de identidad número **${c.rep_documento}**, del mismo domicilio que su representada`;
    }
    return `${c.trat} **${up(c.nombre)}**, ${c.nacionalidad}, ${estadoCivilTexto(c.estado_civil, c.regimen, c.trat)}, ${c.profesion}, ${docTexto(c.doc_tipo, c.documento, c.nacionalidad)}, ${ag(c.trat, 'domiciliado', 'domiciliada')} en ${domicilioTexto(c.domicilio, c.comuna, c.region)}, correo electrónico ${c.email}, quien comparece por sí`;
  }

  function vendedorComparecencia(serie, A) {
    if (serie === 'C') {
      return `la sociedad **${A.odo_razon}**, también denominada "${A.odo_fantasia}", Rol Único Tributario número ${A.odo_rut}, sociedad del giro ${A.odo_giro}, domiciliada en ${A.odo_domicilio}, representada en este acto por su ${A.odo_rep_cargo} ${A.odo_rep_trat} **${A.odo_rep_nombre}**, ${A.odo_rep_nacionalidad}, ${A.odo_rep_estado_civil}, ${A.odo_rep_profesion}, cédula nacional de identidad número ${A.odo_rep_run}, del mismo domicilio que su representada, en adelante, indistintamente, "la sociedad", "la vendedora" o "la parte vendedora"`;
    }
    return `la sociedad **${A.iv_razon}**, Rol Único Tributario número ${A.iv_rut}, del giro ${A.iv_giro}, domiciliada en ${A.iv_domicilio}, representada en este acto por ${A.iv_rep_trat} **${A.iv_rep_nombre}**, ${A.iv_rep_nacionalidad}, ${A.iv_rep_estado_civil}, ${A.iv_rep_profesion}, cédula nacional de identidad número ${A.iv_rep_run}, del mismo domicilio que su representada, en adelante, indistintamente, "el vendedor", "el cedente" o "la parte vendedora"`;
  }

  function medioTexto(medio, serie) {
    if (serie === 'B') return 'transferencia electrónica de fondos a la cuenta del vendedor indicada en esta cláusula';
    return medio === 'tarjeta'
      ? 'pago con tarjeta de crédito en el link de pago de la sociedad'
      : 'transferencia electrónica de fondos a la Cuenta Vista de Mercado Pago de la sociedad';
  }

  function recargoTexto(pct) {
    const [ent, dec] = String(pct).replace(',', '.').split('.');
    return dec && Number(dec) ? `${letras(Number(ent))} coma ${letras(Number(dec))} por ciento` : `${letras(Number(ent))} por ciento`;
  }

  // ── Cláusulas ──────────────────────────────────────────────────────────
  // Cada cláusula: { titulo, parrafos: [ string | {texto, sangria:true} ] }
  function clausulaPago(d, A) {
    const o = d.operacion, serie = o.serie;
    const P = [];
    const vendedorRecibe = serie === 'C' ? 'la parte vendedora' : 'la parte vendedora';
    P.push(`El precio de la presente compraventa${serie === 'C' ? ' y suscripción' : ''} es la suma de **${pesos(o.precio)} por acción**, lo que da un precio total de **${pesos(o.total)}**, que se paga de la siguiente forma:`);
    if (o.forma_pago === 'contado') {
      P.push({ sangria: true, texto: `al contado, con fecha **${fechaLetras(o.pago_fecha)}**, mediante ${medioTexto(o.pago_medio, serie)}, declarando ${vendedorRecibe} haber recibido el precio íntegro a su entera y total satisfacción. En consecuencia, las acciones materia de este contrato quedan íntegramente pagadas.` });
    } else {
      const saldo = o.total - o.pie_monto;
      const pc = planCuotas(saldo, o.cuotas_n, o.cuota_primera, o.periodicidad);
      let cuotasTxt;
      if (pc.n === 1) cuotasTxt = `en una cuota, con vencimiento el **${fechaLetras(o.cuota_primera)}**`;
      else if (pc.base === pc.ultimaMonto) cuotasTxt = `en **${letras(pc.n, 'fem')} cuotas ${o.periodicidad}** de **${pesos(pc.base)}** cada una, con vencimiento la primera el **${fechaLetras(o.cuota_primera)}** y la última el **${fechaLetras(pc.ultima)}**`;
      else cuotasTxt = `en **${letras(pc.n, 'fem')} cuotas ${o.periodicidad}**, las ${pc.n - 1 === 1 ? 'primera' : letras(pc.n - 1, 'fem') + ' primeras'} de **${pesos(pc.base)}** cada una y la última de **${pesos(pc.ultimaMonto)}**, con vencimiento la primera el **${fechaLetras(o.cuota_primera)}** y la última el **${fechaLetras(pc.ultima)}**`;
      let t = `a) con la suma de **${pesos(o.pie_monto)}**, pagada con fecha **${fechaLetras(o.pie_fecha)}** mediante ${medioTexto(o.pie_medio, serie)}, que la parte vendedora declara haber recibido a su entera satisfacción; y b) con el saldo de **${pesos(saldo)}**, que el comprador pagará, por ${serie === 'C' ? 'cualquiera de los medios de pago indicados' : 'el medio de pago indicado'} en esta cláusula, ${cuotasTxt}.`;
      if (serie === 'C' || o.reajuste_uf) t += ' El saldo insoluto se reajustará en la misma proporción en que varíe el valor de la Unidad de Fomento entre la fecha de este contrato y la del pago efectivo de cada cuota.';
      if (serie === 'C') {
        t += ' Mientras las acciones no se encuentren íntegramente pagadas, se aplicará lo dispuesto en el Artículo Octavo de los estatutos: no conferirán derecho a voto, no se computarán para los quórums y participarán en los beneficios sociales y en las devoluciones de capital sólo en proporción a la parte efectivamente pagada. En caso de mora, se aplicará el Artículo Noveno de los estatutos, pudiendo la sociedad cobrar el interés máximo convencional sobre el saldo reajustado y vender, por cuenta y riesgo del comprador, las acciones necesarias para pagarse del saldo insoluto y de los gastos de enajenación.';
      } else {
        t += ' El retardo en el pago de cualquiera de las cuotas hará exigible de inmediato el total del saldo adeudado, como si fuera de plazo vencido, y devengará desde la mora y hasta el pago efectivo el interés máximo convencional que la ley permita estipular.';
      }
      P.push({ sangria: true, texto: t });
    }
    if (serie === 'C') {
      P.push(`**Medios de pago.** El precio, o cada parte de él, se pagará por alguno de los siguientes medios, a elección del comprador: a) transferencia electrónica de fondos a la Cuenta Vista número ${A.c_cuenta_mp} de Mercado Pago, cuyo titular es ${A.odo_razon}, Rol Único Tributario número ${A.odo_rut}; o b) pago con tarjeta de crédito a través del link de pago ${A.c_link_pago}, habilitado por la sociedad en la plataforma Mercado Pago. El pago con tarjeta de crédito tiene un recargo del ${recargoTexto(A.c_recargo_tarjeta)} sobre el monto que se paga por ese medio, el que se suma a dicho monto y es de cargo exclusivo del comprador. Este recargo cubre el costo del medio de pago y no forma parte del precio de colocación de las acciones ni se imputa a capital. En todos los casos, el comprador enviará el comprobante de pago al correo electrónico ${A.c_correo_pagos}, indicando su nombre, su Rol Único Tributario o cédula de identidad y el número de acciones que paga. El pago se entenderá efectuado en la fecha en que los fondos queden disponibles en la cuenta de la sociedad.`);
    } else {
      P.push(`**Medio de pago.** El precio, o cada parte de él, se pagará mediante transferencia electrónica de fondos a la ${A.b_tipo_cuenta} número ${A.b_cuenta} del ${A.b_banco}, cuyo titular es ${A.iv_razon}, Rol Único Tributario número ${A.iv_rut}. El comprador enviará el comprobante de pago al correo electrónico ${A.b_correo_pagos}, indicando su nombre, su Rol Único Tributario o cédula de identidad y el número de acciones que paga. El pago se entenderá efectuado en la fecha en que los fondos queden disponibles en la cuenta del vendedor.`);
      P.push('Las partes dejan constancia de que, por tratarse de acciones ya suscritas y pagadas, el precio de esta compraventa ingresa al patrimonio del vendedor y no a la caja social, y no produce aumento ni modificación alguna del capital de la sociedad.');
    }
    return P;
  }

  function precioRondaTexto(o) {
    const acuerdo = o.acuerdo_dir && o.acuerdo_fecha ? `por acuerdo del Directorio adoptado en sesión de fecha ${fechaLetras(o.acuerdo_fecha)}` : '';
    if (o.ronda && acuerdo) return `El precio de la presente colocación corresponde al fijado para la ronda **${o.ronda}**, ${acuerdo}.`;
    if (o.ronda) return `El precio de la presente colocación corresponde al fijado para la ronda **${o.ronda}**.`;
    if (acuerdo) return `El precio de la presente colocación fue fijado ${acuerdo}.`;
    return 'El precio de la presente colocación ha sido fijado por la administración de la sociedad dentro de las facultades que le confieren los estatutos.';
  }

  const CAPITAL = 'De acuerdo con el Artículo Quinto de sus estatutos, el capital de la sociedad asciende a cuatrocientos ocho millones trescientos treinta mil pesos, dividido en tres millones trescientas treinta mil acciones nominativas, sin valor nominal, distribuidas en tres series: Serie A, un millón de acciones; Serie B, trescientas treinta mil acciones; y Serie C, dos millones de acciones.';

  function origenFondos(d, serie) {
    const o = d.operacion;
    const intro = 'La Ley número veinte mil trescientos noventa y tres establece la responsabilidad penal de las personas jurídicas respecto de los delitos que señala, entre ellos el lavado de activos, el financiamiento del terrorismo, el cohecho a funcionarios públicos nacionales o extranjeros, la receptación, la apropiación indebida, la administración desleal, la corrupción entre particulares y los demás que dicho cuerpo legal contempla con sus modificaciones.';
    const ctx = serie === 'C'
      ? 'En este contexto, ODO SERVICIOS FINANCIEROS SpA mantiene un Modelo de Prevención de Delitos, y el comprador declara bajo su responsabilidad que:'
      : 'En este contexto, y en atención a que ODO SERVICIOS FINANCIEROS SpA mantiene un Modelo de Prevención de Delitos que se extiende a la incorporación de nuevos accionistas, el comprador declara bajo su responsabilidad que:';
    const quien = serie === 'C' ? 'a la sociedad' : 'al vendedor y a la sociedad';
    return `${intro} ${ctx} a) los fondos con que paga el precio provienen de **${o.origen_fondos}**, son de su patrimonio y tienen origen lícito; b) dichos fondos no provienen ni se relacionan con actividades constitutivas de los delitos de la Ley número diecinueve mil novecientos trece, de la Ley número dieciocho mil trescientos catorce ni de la Ley número veinte mil trescientos noventa y tres; c) no actúa como testaferro ni por cuenta de terceros no individualizados en este instrumento; y d) se obliga a entregar ${quien} los antecedentes que ésta le solicite para verificar lo anterior, en cumplimiento de sus procedimientos de debida diligencia.`.replace('que ésta le solicite', serie === 'C' ? 'que ésta le solicite' : 'que éstos le soliciten');
  }

  function inversionExtranjera(o) {
    return o.inversion_ext === 'B'
      ? 'La parte compradora declara que los recursos con que paga el precio de esta compraventa provienen del exterior y han ingresado al país por intermedio de una entidad del Mercado Cambiario Formal, obligándose el comprador a efectuar o hacer efectuar los informes que correspondan conforme al Capítulo XIV del Compendio de Normas de Cambios Internacionales del Banco Central de Chile vigente, y a entregar copia de ellos a la sociedad.'
      : 'La parte compradora declara que los recursos con que paga el precio de esta compraventa no provienen del exterior ni constituyen inversión extranjera, por tratarse de recursos obtenidos y mantenidos en Chile.';
  }

  function firmaElectronica(A, conTestigos) {
    return `Las partes acuerdan suscribir el presente contrato por medio de firma electrónica, a través de la plataforma ${A.plataforma_firma}, en conformidad con la Ley número diecinueve mil setecientos noventa y nueve sobre Documentos Electrónicos, Firma Electrónica y Servicios de Certificación de dicha Firma. Conforme al artículo tercero de dicha ley, el contrato así suscrito es válido y produce los mismos efectos que si se hubiera celebrado por escrito y en soporte de papel. Las partes reconocen como propias las firmas electrónicas que estampen en este instrumento y como original el documento electrónico resultante, del cual cada una conservará un ejemplar${conTestigos ? '. La misma regla se aplica a la firma de los testigos' : ''}. El contrato se entenderá perfeccionado en la fecha en que se estampe la última de las firmas.`;
  }

  function arbitraje() {
    return 'El presente contrato se rige por las leyes de la República de Chile. Para todos sus efectos, las partes fijan domicilio en la comuna y ciudad de Santiago. Toda duda, dificultad o controversia que surja entre las partes con motivo de la interpretación, validez, cumplimiento o terminación de este contrato será resuelta por un árbitro mixto, en la forma prevista en el Artículo Vigésimo Tercero de los estatutos de la sociedad ODO SERVICIOS FINANCIEROS SpA, el que se constituirá en la comuna de Santiago.';
  }

  function poderEspecial(A) {
    return `Los comparecientes confieren poder especial al abogado ${A.abogado_nombre}, cédula nacional de identidad número ${A.abogado_run}, para que, actuando individualmente, pueda aclarar, complementar o salvar las omisiones y rectificar los errores de copia, de referencia o de cálculos numéricos que aparezcan de manifiesto en el presente contrato, en especial en relación con la correcta individualización de los comparecientes y de las acciones, quedando facultado para suscribir los instrumentos públicos y privados que sean necesarios para el cumplimiento de su cometido.`;
  }

  function clausulasC(d, A) {
    const o = d.operacion, c = d.comprador;
    const dias = parseInt(o.dias_registro, 10) || 5;
    const pers = [`La personería de ${A.odo_rep_trat} ${titulo(A.odo_rep_nombre)} para representar a ${A.odo_razon} consta en ${sinConsta(A.odo_rep_personeria)}.`];
    if (c.tipo === 'juridica') pers.push(`La personería de ${c.rep_trat} ${titulo(c.rep_nombre)} para representar a ${up(c.nombre)} consta en ${personeriaCompradorTexto(c)}.`);
    return [
      { t: 'Antecedentes de la sociedad', p: [A.odo_antecedentes] },
      { t: 'Capital social y acciones Serie C', p: [`${CAPITAL} Las acciones de las Series A y B se encuentran íntegramente suscritas y pagadas. Las acciones de la Serie C permanecen emitidas y no colocadas, y conforme al Artículo Sexto número Cuatro de los estatutos pueden ser colocadas por la administración, a un precio no inferior a ${letras(Number(A.c_precio_minimo), 'apoc')} pesos por acción, dentro del plazo de treinta y seis meses contado desde la fecha de la escritura social, esto es, hasta el ${fechaLetras(A.c_plazo_maximo)}, según su Artículo Séptimo. Los accionistas constituyentes renunciaron expresa e irrevocablemente al derecho preferente de suscripción respecto de dichas acciones, según el Artículo Duodécimo de los estatutos. ${precioRondaTexto(o)}`] },
      { t: 'De la venta y suscripción', p: [`Por el presente instrumento, ${A.odo_razon}, debidamente representada en la forma indicada, vende, coloca y transfiere a **${up(c.nombre)}**, quien compra, suscribe y acepta para sí, **${acciones(o.cantidad)} de la Serie C** de la sociedad ${A.odo_razon}, nominativas y sin valor nominal, de primera emisión.`] },
      { t: 'Precio, forma y medios de pago', p: clausulaPago(d, A) },
      { t: 'Derechos de las acciones', p: ['Las acciones que se venden confieren los derechos propios de la Serie C establecidos en el Artículo Décimo de los estatutos, que el comprador declara conocer y aceptar, entre ellos: a) un voto por acción, en circunstancias que cada acción de la Serie A otorga diez votos; b) participación en los dividendos que acuerde la junta de accionistas a prorrata de las acciones íntegramente pagadas, sin dividendo preferente, mínimo ni acumulativo, y sin aplicación del dividendo mínimo del artículo setenta y nueve de la Ley número dieciocho mil cuarenta y seis; c) preferencia en caso de liquidación o disolución de la sociedad para percibir, antes que las Series A y B, una suma equivalente al monto efectivamente pagado por sus acciones, debidamente reajustado, pudiendo optar por renunciar a ella y participar a prorrata en la totalidad del haber social. Esta preferencia no confiere derecho a rescate ni a exigir pago alguno fuera del caso de liquidación o disolución, y tiene una vigencia de treinta años contados desde la fecha de la escritura social. Las acciones no se representan en láminas o títulos físicos; su titularidad se acredita con la inscripción en el Registro de Accionistas y con el certificado que emita la sociedad.'] },
      { t: 'Estado de las acciones', p: ['Las acciones que se venden, colocan y transfieren son de primera emisión y se entregan libres de toda prohibición, gravamen, embargo, litigio o derecho de terceros, respondiendo la vendedora del saneamiento de la evicción en conformidad a la ley.'] },
      { t: 'Declaraciones del inversionista', p: ['El comprador declara: a) conocer los estatutos de la sociedad y la información que ésta le ha proporcionado sobre su proyecto, estado de desarrollo, proyecciones y riesgos; b) entender que se trata de una inversión de riesgo en una sociedad en etapa inicial, que las proyecciones son estimaciones que pueden no cumplirse, que la sociedad no garantiza rentabilidad ni devolución del capital invertido, y que no existe mercado secundario para estas acciones; c) que la presente colocación es una oferta privada dirigida a él en particular y no constituye oferta pública de valores en los términos de la Ley número dieciocho mil cuarenta y cinco; y d) que el precio pagado constituye aporte de capital a la sociedad y no un depósito, captación ni administración de fondos de terceros, actividades que el objeto social de ODO excluye expresamente.'] },
      { t: 'Responsabilidad penal de las personas jurídicas y origen de los fondos', p: [origenFondos(d, 'C')] },
      { t: 'Declaración sobre inversión extranjera', p: [inversionExtranjera(o)] },
      { t: 'Lesión enorme', p: ['Las partes declaran que el precio ha sido fijado conforme a los estatutos sociales y a las condiciones de la ronda de colocación, y que no procede en este contrato la acción rescisoria por lesión enorme, la que conforme al artículo mil ochocientos noventa y uno del Código Civil sólo tiene lugar en la compraventa de bienes inmuebles, y en todo caso renuncian a ella.'] },
      { t: 'Gastos', p: ['Los gastos de cualquier naturaleza que irroguen el otorgamiento del presente contrato y las inscripciones que procedan serán de cargo exclusivo de la parte compradora.'] },
      { t: 'Registro de Accionistas y comunicaciones', p: [`La sociedad inscribirá al comprador como titular de las acciones materia de este contrato en su Registro de Accionistas, dejando constancia de la serie, de su estado de pago y de las preferencias del Artículo Décimo de los estatutos, dentro de los **${letras(dias, 'masc')}** días hábiles siguientes a la fecha de este contrato, y le remitirá el certificado de su calidad de accionista. Se deja constancia de que, conforme al Artículo Vigésimo Segundo de los estatutos, toda comunicación oficial de la sociedad se enviará al correo electrónico indicado por el comprador en la comparecencia, que se registrará para tal efecto en el Registro de Accionistas, obligándose el comprador a informar cualquier cambio.`] },
      { t: 'Poder especial', p: [poderEspecial(A)] },
      { t: 'Facultad especial', p: ['Se faculta al portador de un ejemplar de este contrato suscrito electrónicamente para requerir y firmar las anotaciones que procedan en el Registro de Accionistas de la sociedad y para efectuar las comunicaciones y declaraciones que correspondan ante el Servicio de Impuestos Internos y demás autoridades. Esta facultad es irrevocable y subsistirá aunque sobrevenga la muerte o incapacidad de cualquiera de los contratantes.'] },
      { t: 'Domicilio y solución de controversias', p: [arbitraje()] },
      { t: 'Firma electrónica', p: [firmaElectronica(A, !!o.testigos_incluir)] },
      { t: 'Personería', p: [pers.join(' ') + ' Personerías que no se insertan por ser conocidas de las partes.'] },
    ];
  }

  function clausulasB(d, A) {
    const o = d.operacion, c = d.comprador;
    const dias = parseInt(o.dias_registro, 10) || 5;
    const pers = [`La personería de ${A.iv_rep_trat} ${titulo(A.iv_rep_nombre)} para actuar en representación de la sociedad ${A.iv_razon} o IVELSA consta en certificado de poderes del Registro de Empresas y Sociedades del Ministerio de Economía, Fomento y Turismo, de fecha ${fechaLetras(A.iv_pers_fecha)}. El código de verificación electrónica es ${A.iv_pers_cve}.`];
    if (c.tipo === 'juridica') pers.push(`La personería de ${c.rep_trat} ${titulo(c.rep_nombre)} para representar a ${up(c.nombre)} consta en ${personeriaCompradorTexto(c)}.`);
    return [
      { t: 'Antecedentes de la sociedad', p: [`${A.odo_antecedentes} Su Rol Único Tributario es el número ${A.odo_rut}. En adelante, "la sociedad" u "ODO".`] },
      { t: 'Capital social y dominio de las acciones', p: [`${CAPITAL} Las acciones de la Serie B fueron íntegramente suscritas y pagadas por el vendedor en el acto de constitución de la sociedad. A la fecha de este contrato, el vendedor es dueño de **${acciones(o.tenencia_vendedor)} de la Serie B**, íntegramente pagadas e inscritas a su nombre en el Registro de Accionistas de la sociedad.`] },
      { t: 'De la compraventa y cesión', p: [`Por el presente instrumento, ${A.iv_razon}, debidamente representada en la forma indicada, vende, cede y transfiere a **${up(c.nombre)}**, quien compra, acepta y adquiere para sí, **${acciones(o.cantidad)} de la Serie B** de la sociedad ODO SERVICIOS FINANCIEROS SpA, nominativas, sin valor nominal e íntegramente pagadas, de aquellas singularizadas en la cláusula precedente.`] },
      { t: 'Precio, forma y medio de pago', p: clausulaPago(d, A) },
      { t: 'Derechos de las acciones', p: ['Las acciones que se venden confieren los derechos propios de la Serie B establecidos en el Artículo Décimo de los estatutos, que el comprador declara conocer y aceptar, entre ellos: a) un voto por acción, en circunstancias que cada acción de la Serie A otorga diez votos; b) participación en los dividendos que acuerde la junta de accionistas a prorrata de las acciones íntegramente pagadas, sin dividendo preferente, mínimo ni acumulativo, y sin aplicación del dividendo mínimo del artículo setenta y nueve de la Ley número dieciocho mil cuarenta y seis; y c) en caso de liquidación o disolución de la sociedad, participación en el haber social a prorrata, una vez satisfecha la preferencia que el Artículo Décimo de los estatutos confiere a la Serie C. Las acciones no se representan en láminas o títulos físicos; su titularidad se acredita con la inscripción en el Registro de Accionistas y con el certificado que emita la sociedad.'] },
      { t: 'Estado de las acciones', p: ['El vendedor declara que las acciones que vende, cede y transfiere son de su exclusivo dominio, se encuentran íntegramente pagadas y se entregan libres de toda prohibición, gravamen, embargo, litigio o derecho de terceros, respondiendo el vendedor del saneamiento de la evicción en conformidad a la ley.'] },
      { t: 'Declaraciones del comprador', p: ['El comprador declara: a) conocer los estatutos de la sociedad y la información que se le ha proporcionado sobre su proyecto, estado de desarrollo, proyecciones y riesgos; b) entender que se trata de una inversión de riesgo en una sociedad en etapa inicial, que las proyecciones son estimaciones que pueden no cumplirse, que ni el vendedor ni la sociedad garantizan rentabilidad ni devolución del precio pagado, y que no existe mercado secundario para estas acciones; y c) que la presente es una operación privada y directa entre las partes, que no constituye oferta pública de valores en los términos de la Ley número dieciocho mil cuarenta y cinco.'] },
      { t: 'Responsabilidad penal de las personas jurídicas y origen de los fondos', p: [origenFondos(d, 'B')] },
      { t: 'Declaración sobre inversión extranjera', p: [inversionExtranjera(o)] },
      { t: 'Lesión enorme', p: ['Las partes declaran que el precio ha sido libremente convenido entre ellas, y que no procede en este contrato la acción rescisoria por lesión enorme, la que conforme al artículo mil ochocientos noventa y uno del Código Civil sólo tiene lugar en la compraventa de bienes inmuebles, y en todo caso renuncian a ella.'] },
      { t: 'Traspaso, inscripción y comunicaciones', p: [`El presente instrumento constituye el traspaso de las acciones y se suscribe por el cedente y el cesionario ante los dos testigos mayores de edad que se individualizan al final, en conformidad con el artículo treinta y siete de la Ley número dieciocho mil cuarenta y seis y su Reglamento. Las partes se obligan a comunicar el traspaso a la sociedad, acompañándole un ejemplar de este contrato, para que ésta lo inscriba en su Registro de Accionistas dentro de los **${letras(dias, 'masc')}** días hábiles siguientes a su recepción y remita al comprador el certificado de su calidad de accionista. Se deja constancia de que, conforme al Artículo Vigésimo Segundo de los estatutos, toda comunicación oficial de la sociedad se enviará al correo electrónico indicado por el comprador en la comparecencia, que se registrará para tal efecto en el Registro de Accionistas, obligándose el comprador a informar cualquier cambio.`] },
      { t: 'Gastos', p: ['Los gastos de cualquier naturaleza que irroguen el otorgamiento del presente contrato y las inscripciones que procedan serán de cargo exclusivo de la parte compradora.'] },
      { t: 'Poder especial', p: [poderEspecial(A)] },
      { t: 'Facultad especial', p: ['Se faculta al portador de un ejemplar de este contrato suscrito electrónicamente para requerir y firmar las anotaciones que procedan en el Registro de Accionistas de la sociedad y para efectuar las comunicaciones y declaraciones que correspondan ante el Servicio de Impuestos Internos y demás autoridades. Esta facultad es irrevocable y subsistirá aunque sobrevenga la muerte o incapacidad de cualquiera de los contratantes.'] },
      { t: 'Domicilio y solución de controversias', p: [arbitraje()] },
      { t: 'Firma electrónica', p: [firmaElectronica(A, true)] },
      { t: 'Personería', p: [pers.join(' ') + ' Personerías que no se insertan por ser conocidas de las partes.'] },
    ];
  }

  function sinConsta(s) { return String(s).trim().replace(/^consta en\s+/i, '').replace(/\.$/, ''); }

  // Mayúsculas conservando la sigla legal «SpA»
  function up(s) { return String(s).toUpperCase().replace(/\bSPA\b/g, 'SpA'); }

  function titulo(s) {
    return String(s).toLowerCase().replace(/(^|[\s-])([a-záéíóúñü])/g, (m, a, b) => a + b.toUpperCase());
  }

  // ── Documento completo (estructura neutra) ─────────────────────────────
  function construir(d, A) {
    const o = d.operacion, c = d.comprador, serie = o.serie;
    const enc = serie === 'C'
      ? ['CONTRATO DE SUSCRIPCIÓN Y COMPRAVENTA', 'DE ACCIONES SERIE C', '', A.odo_razon, 'a', up(c.nombre)]
      : ['CONTRATO DE COMPRAVENTA Y CESIÓN', 'DE ACCIONES SERIE B', 'DE ' + A.odo_razon, '', A.iv_razon, 'a', up(c.nombre)];
    const intro = `En ${A.ciudad_firma}, República de Chile, a ${fechaLetras(o.fecha_contrato)}, comparecen: por una parte, ${vendedorComparecencia(serie, A)}; y por otra parte, ${compradorComparecencia(c)}; en adelante, indistintamente, "el comprador", ${serie === 'C' ? '"el inversionista"' : '"el cesionario"'} o "la parte compradora". Los comparecientes, mayores de edad, exponen que han convenido en el siguiente contrato:`;
    const cl = (serie === 'C' ? clausulasC(d, A) : clausulasB(d, A)).map((x, i) => ({ ord: ORD[i], titulo: x.t, parrafos: x.p }));

    const firmas = [];
    if (serie === 'C') firmas.push({ nombre: A.odo_rep_nombre, lineas: [`p.p. ${A.odo_razon}`, `RUT ${A.odo_rut}`], rol: 'Vendedora' });
    else firmas.push({ nombre: A.iv_rep_nombre, lineas: [`p.p. ${A.iv_razon}`, `RUT ${A.iv_rut}`], rol: 'Vendedor' });
    if (c.tipo === 'juridica') firmas.push({ nombre: c.rep_nombre.toUpperCase(), lineas: [`p.p. ${up(c.nombre)}`, `RUT ${c.documento}`], rol: 'Comprador' });
    else firmas.push({ nombre: up(c.nombre), lineas: [c.doc_tipo === 'pasaporte' ? `Pasaporte ${c.documento}` : `RUN ${c.documento}`], rol: c.trat === 'doña' ? 'Compradora' : 'Comprador' });

    const testigos = (serie === 'B' || o.testigos_incluir) ? (o.testigos || []).filter(t => t && t.nombre) : [];
    return { encabezado: enc, intro, clausulas: cl, firmas, testigos };
  }

  // ── Markup **negrita** → runs de pdfmake ───────────────────────────────
  // La puntuación que sigue a un tramo en negrita se une a ese tramo: pdfmake, al
  // justificar, agrega espacio al final de cada tramo y dejaría «ROJAS ,».
  function runs(s) {
    const out = [];
    String(s).replace(/"([^"]*)"/g, '\u201C$1\u201D').split(/(\*\*[^*]+\*\*)/g).forEach(part => {
      if (!part) return;
      if (part.startsWith('**') && part.endsWith('**')) { out.push({ text: part.slice(2, -2), bold: true }); return; }
      const prev = out[out.length - 1];
      const m = prev && prev.bold ? part.match(/^[,.;:)]+/) : null;
      if (m) { prev.text += m[0]; part = part.slice(m[0].length); }
      if (part) out.push({ text: part });
    });
    // Los RUT no se cortan en el guion al final de una línea
    const RUT = /(\d{1,3}(?:\.\d{3})+-[\dkK])/;
    const partes = out.flatMap(r => String(r.text).split(RUT).filter(Boolean)
      .map(t => (RUT.test(t) && t.match(RUT)[0] === t ? { ...r, text: t, noWrap: true } : { ...r, text: t })));
    // Misma corrección de puntuación que en las negritas
    const fin = [];
    partes.forEach(r => {
      const prev = fin[fin.length - 1];
      const m = prev && prev.noWrap ? r.text.match(/^[,.;:)]+/) : null;
      if (m) { prev.text += m[0]; r = { ...r, text: r.text.slice(m[0].length) }; }
      if (r.text) fin.push(r);
    });
    return fin;
  }

  function pdfDefinicion(d, A, meta) {
    const doc = construir(d, A);
    const content = [];
    doc.encabezado.forEach((l, i) => {
      if (!l) { content.push({ text: ' ', fontSize: 6 }); return; }
      content.push({ text: l, alignment: 'center', bold: l !== 'a', italics: l === 'a', fontSize: i < 2 ? 13 : 12, margin: [0, 0, 0, 2] });
    });
    content.push({ canvas: [{ type: 'line', x1: 170, y1: 6, x2: 298, y2: 6, lineWidth: 0.8, lineColor: '#96772A' }], margin: [0, 4, 0, 16] });
    content.push({ text: runs(doc.intro), style: 'p' });
    doc.clausulas.forEach(c => {
      c.parrafos.forEach((p, i) => {
        const txt = typeof p === 'string' ? p : p.texto;
        const r = runs(txt);
        if (i === 0) r.unshift({ text: `${c.ord}: ${c.titulo}. `, bold: true });
        content.push({ text: r, style: 'p', margin: typeof p === 'object' && p.sangria ? [28, 0, 0, 9] : [0, 0, 0, 9] });
      });
    });

    // Bloque de firmas: espacio amplio para el sello de FirmaYa
    const celda = f => ({
      stack: [
        { text: ' ', margin: [0, 0, 0, 62] },
        { canvas: [{ type: 'line', x1: 0, y1: 0, x2: 200, y2: 0, lineWidth: 0.7 }] },
        { text: f.nombre, bold: true, fontSize: 10.5, margin: [0, 4, 0, 0] },
        ...f.lineas.map(l => ({ text: l, fontSize: 10 })),
        { text: f.rol, fontSize: 9, italics: true, color: '#555555' },
      ], alignment: 'left',
    });
    const filas = [];
    for (let i = 0; i < doc.firmas.length; i += 2) filas.push({ columns: [celda(doc.firmas[i]), doc.firmas[i + 1] ? celda(doc.firmas[i + 1]) : { text: '' }], columnGap: 40 });
    const tfilas = [];
    const tcelda = t => ({ stack: [
      { text: ' ', margin: [0, 0, 0, 52] },
      { canvas: [{ type: 'line', x1: 0, y1: 0, x2: 200, y2: 0, lineWidth: 0.7 }] },
      { text: t.nombre.toUpperCase(), bold: true, fontSize: 10.5, margin: [0, 4, 0, 0] },
      { text: `RUN ${t.rut}`, fontSize: 10 },
      { text: 'Testigo', fontSize: 9, italics: true, color: '#555555' },
    ] });
    for (let i = 0; i < doc.testigos.length; i += 2) tfilas.push({ columns: [tcelda(doc.testigos[i]), doc.testigos[i + 1] ? tcelda(doc.testigos[i + 1]) : { text: '' }], columnGap: 40 });

    content.push({ stack: [{ text: 'Firmas', bold: true, fontSize: 11, margin: [0, 14, 0, 0], color: '#0C3A30' }, ...filas], unbreakable: true });
    if (tfilas.length) content.push({ stack: tfilas, unbreakable: true, margin: [0, 10, 0, 0] });

    return {
      pageSize: 'LETTER',
      pageMargins: [72, 64, 72, 64],
      info: { title: `${meta.folio} — Acciones Serie ${d.operacion.serie} — ${d.comprador.nombre}`, author: A.odo_razon, subject: 'Contrato para firma electrónica', creator: 'Minutas ODO' },
      defaultStyle: { font: 'Serif', fontSize: 11.5, lineHeight: 1.3 },
      styles: { p: { alignment: 'justify' } },
      content,
      footer: (page, pages) => ({
        margin: [72, 20, 72, 0],
        columns: [
          { text: `Folio ${meta.folio}${meta.version ? ' · v' + meta.version : ''}`, fontSize: 8, color: '#777777' },
          { text: `Documento para firma electrónica · ${A.plataforma_firma}`, fontSize: 8, color: '#777777', alignment: 'center' },
          { text: `Página ${page} de ${pages}`, fontSize: 8, color: '#777777', alignment: 'right' },
        ],
      }),
    };
  }

  function generarPdf(d, A, meta) {
    const fonts = { Serif: { normal: 'Serif-Regular.ttf', bold: 'Serif-Bold.ttf', italics: 'Serif-Italic.ttf', bolditalics: 'Serif-BoldItalic.ttf' } };
    return pdfMake.createPdf(pdfDefinicion(d, A, meta), null, fonts);
  }

  global.Minuta = { letras, fmt, pesos, acciones, fechaLetras, fechaCorta, sumarMeses, planCuotas, estadoCivilTexto, construir, pdfDefinicion, generarPdf, titulo };
  if (typeof module !== 'undefined') module.exports = global.Minuta;
})(typeof window !== 'undefined' ? window : globalThis);
