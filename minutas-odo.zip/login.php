<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
security_headers();
if (!is_installed()) { header('Location: install.php'); exit; }
start_session();
if (current_user()) { header('Location: index.php'); exit; }

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $pass  = (string)($_POST['password'] ?? '');
    if (!check_csrf($_POST['csrf'] ?? null)) {
        $error = 'La sesión expiró. Vuelva a intentarlo.';
    } else {
        $st = db()->prepare('SELECT * FROM usuarios WHERE email = ?');
        $st->execute([$email]);
        $u = $st->fetch();
        if ($u && $u['bloqueado_hasta'] && strtotime($u['bloqueado_hasta']) > time()) {
            $error = 'Usuario bloqueado temporalmente por intentos fallidos. Intente en 15 minutos.';
        } elseif ($u && $u['activo'] && password_verify($pass, $u['pass_hash'])) {
            session_regenerate_id(true);
            $_SESSION['uid'] = (int)$u['id'];
            db()->prepare('UPDATE usuarios SET intentos_fallidos=0, bloqueado_hasta=NULL, ultimo_ingreso=NOW() WHERE id=?')->execute([$u['id']]);
            bitacora('ingreso', ['email' => $email]);
            header('Location: ' . ($u['debe_cambiar'] ? 'cambiar-clave.php' : 'index.php'));
            exit;
        } else {
            if ($u) {
                $n = (int)$u['intentos_fallidos'] + 1;
                $bloq = $n >= 5 ? date('Y-m-d H:i:s', time() + 900) : null;
                db()->prepare('UPDATE usuarios SET intentos_fallidos=?, bloqueado_hasta=? WHERE id=?')
                    ->execute([$bloq ? 0 : $n, $bloq, $u['id']]);
            }
            db()->prepare('INSERT INTO bitacora (accion, detalle, ip) VALUES (?,?,?)')
                ->execute(['ingreso_fallido', json_encode(['email' => $email]), $_SERVER['REMOTE_ADDR'] ?? '']);
            usleep(400000);
            $error = 'Correo o clave incorrectos.';
        }
    }
}
?><!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ingreso · Minutas ODO</title><link rel="stylesheet" href="assets/app.css"></head>
<body class="auth"><main class="auth-card">
  <div class="brand"><span class="brand-inf">∞</span><span class="brand-word">Odo</span></div>
  <h1>Minutas de compraventa de acciones</h1>
  <?php if ($error): ?><p class="alert err"><?= h($error) ?></p><?php endif; ?>
  <form method="post" autocomplete="on">
    <input type="hidden" name="csrf" value="<?= h(csrf_token()) ?>">
    <label>Correo<input type="email" name="email" required autofocus value="<?= h($_POST['email'] ?? '') ?>"></label>
    <label>Clave<input type="password" name="password" required></label>
    <button class="btn primary block" type="submit">Ingresar</button>
  </form>
</main></body></html>
