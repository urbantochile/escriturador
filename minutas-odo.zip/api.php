<?php
declare(strict_types=1);
require __DIR__ . '/lib/bootstrap.php';
security_headers();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function out($data, int $code = 200): never {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function fail(string $msg, int $code = 400): never { out(['error' => $msg], $code); }

function rut_valido(string $rut): bool {
    $r = strtoupper(preg_replace('/[^0-9kK]/', '', $rut));
    if (strlen($r) < 2) return false;
    $cuerpo = substr($r, 0, -1); $dv = substr($r, -1);
    if (!ctype_digit($cuerpo)) return false;
    $s = 0; $m = 2;
    for ($i = strlen($cuerpo) - 1; $i >= 0; $i--) { $s += (int)$cuerpo[$i] * $m; $m = $m === 7 ? 2 : $m + 1; }
    $d = 11 - ($s % 11);
    $esp = $d === 11 ? '0' : ($d === 10 ? 'K' : (string)$d);
    return $esp === $dv;
}
function rut_normal(string $rut): string {
    $r = strtoupper(preg_replace('/[^0-9kK]/', '', $rut));
    $c = substr($r, 0, -1); $dv = substr($r, -1);
    return number_format((int)$c, 0, ',', '.') . '-' . $dv;
}

function cupos(?int $excluirId = null): array {
    $a = ajustes();
    $sql = "SELECT serie, COALESCE(SUM(cantidad),0) s FROM operaciones
            WHERE estado IN ('generada','firmada')" . ($excluirId ? ' AND id <> ' . (int)$excluirId : '') . ' GROUP BY serie';
    $usado = ['B' => 0, 'C' => 0];
    foreach (db()->query($sql) as $r) $usado[$r['serie']] = (int)$r['s'];
    return [
        'C' => ['total' => (int)$a['c_total_serie'], 'comprometido' => $usado['C'], 'disponible' => (int)$a['c_total_serie'] - $usado['C']],
        'B' => ['total' => (int)$a['b_tenencia_inicial'], 'comprometido' => $usado['B'], 'disponible' => (int)$a['b_tenencia_inicial'] - $usado['B']],
    ];
}

function body(): array {
    $b = json_decode(file_get_contents('php://input') ?: '[]', true);
    return is_array($b) ? $b : [];
}

// ── Autenticación ───────────────────────────────────────────────────────
if (!is_installed()) fail('Plataforma no instalada', 503);
$user = current_user();
if (!$user) fail('Sesión no iniciada', 401);
$st = db()->prepare('SELECT debe_cambiar FROM usuarios WHERE id=?'); $st->execute([$user['id']]);
if ((int)$st->fetchColumn() === 1) fail('Debe cambiar su clave antes de continuar', 403);

$action = $_GET['a'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$isMaster = $user['rol'] === 'master';

if ($method === 'POST') {
    if (!check_csrf($_SERVER['HTTP_X_CSRF'] ?? null)) fail('Token de seguridad inválido. Recargue la página.', 419);
}
function master_only(): void { global $isMaster; if (!$isMaster) fail('Acción reservada al usuario máster', 403); }

try {
switch ("$method $action") {

// ── Sesión y ajustes ────────────────────────────────────────────────────
case 'GET sesion':
    out(['usuario' => $user, 'ajustes' => ajustes(), 'cupos' => cupos(), 'csrf' => csrf_token(), 'version' => APP_VERSION]);

case 'POST ajustes':
    master_only();
    $b = body();
    $defaults = require __DIR__ . '/lib/defaults.php';
    $st = db()->prepare('INSERT INTO ajustes (clave, valor) VALUES (?,?) ON DUPLICATE KEY UPDATE valor=VALUES(valor)');
    $cambios = [];
    foreach ($b as $k => $v) {
        if (!array_key_exists($k, $defaults)) continue;
        $st->execute([$k, trim((string)$v)]);
        $cambios[] = $k;
    }
    bitacora('ajustes', ['claves' => $cambios]);
    out(['ok' => true, 'ajustes' => ajustes(), 'cupos' => cupos()]);

// ── Compradores ─────────────────────────────────────────────────────────
case 'GET compradores':
    $q = trim((string)($_GET['q'] ?? ''));
    if ($q === '') {
        $rows = db()->query('SELECT id, tipo, doc_tipo, documento, nombre, email, telefono, comuna, region, actualizado_en,
            (SELECT COUNT(*) FROM operaciones o WHERE o.comprador_id=c.id AND o.estado<>\'anulada\') AS operaciones
            FROM compradores c ORDER BY actualizado_en DESC LIMIT 300')->fetchAll();
    } else {
        $like = '%' . $q . '%';
        $plain = '%' . preg_replace('/[^0-9kK]/', '', $q) . '%';
        $st = db()->prepare('SELECT id, tipo, doc_tipo, documento, nombre, email, telefono, comuna, region, actualizado_en,
            (SELECT COUNT(*) FROM operaciones o WHERE o.comprador_id=c.id AND o.estado<>\'anulada\') AS operaciones
            FROM compradores c WHERE nombre LIKE ? OR email LIKE ? OR REPLACE(REPLACE(documento,\'.\',\'\'),\'-\',\'\') LIKE ?
            ORDER BY nombre LIMIT 50');
        $st->execute([$like, $like, $plain === '%%' ? $like : $plain]);
        $rows = $st->fetchAll();
    }
    out(['compradores' => $rows]);

case 'GET comprador':
    $st = db()->prepare('SELECT * FROM compradores WHERE id=?');
    $st->execute([(int)($_GET['id'] ?? 0)]);
    $c = $st->fetch() ?: fail('Comprador no encontrado', 404);
    $c['datos'] = json_decode($c['datos'], true);
    out(['comprador' => $c]);

case 'GET exportar_compradores':
    master_only();
    $rows = db()->query('SELECT * FROM compradores ORDER BY nombre')->fetchAll();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="compradores-odo-' . date('Ymd') . '.csv"');
    $f = fopen('php://output', 'w');
    fwrite($f, "\xEF\xBB\xBF");
    $cols = ['tipo','doc_tipo','documento','nombre','email','telefono','nacionalidad','estado_civil','profesion','giro','domicilio','comuna','region','rep_nombre','rep_documento','creado_en','actualizado_en'];
    fputcsv($f, $cols, ';');
    foreach ($rows as $r) {
        $d = json_decode($r['datos'], true) ?: [];
        fputcsv($f, [$r['tipo'],$r['doc_tipo'],$r['documento'],$r['nombre'],$r['email'],$r['telefono'],
            $d['nacionalidad'] ?? '', $d['estado_civil_texto'] ?? '', $d['profesion'] ?? '', $d['giro'] ?? '',
            $d['domicilio'] ?? '', $r['comuna'], $r['region'], $d['rep_nombre'] ?? '', $d['rep_documento'] ?? '',
            $r['creado_en'], $r['actualizado_en']], ';');
    }
    bitacora('exportar_compradores', ['n' => count($rows)]);
    exit;

// ── Operaciones ─────────────────────────────────────────────────────────
case 'GET operaciones':
    $w = []; $p = [];
    if (in_array($_GET['serie'] ?? '', ['B','C'], true)) { $w[] = 'o.serie=?'; $p[] = $_GET['serie']; }
    if (in_array($_GET['estado'] ?? '', ['borrador','generada','firmada','anulada'], true)) { $w[] = 'o.estado=?'; $p[] = $_GET['estado']; }
    if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(o.folio LIKE ? OR c.nombre LIKE ? OR c.documento LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
    $st = db()->prepare('SELECT o.id, o.folio, o.serie, o.cantidad, o.precio_unitario, o.total, o.forma_pago, o.fecha_contrato,
        o.estado, o.version, o.pdf_sha256, o.creado_en, o.actualizado_en, c.nombre AS comprador, c.documento, u.email AS creado_por
        FROM operaciones o JOIN compradores c ON c.id=o.comprador_id LEFT JOIN usuarios u ON u.id=o.creado_por'
        . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . ' ORDER BY o.id DESC LIMIT 500');
    $st->execute($p);
    out(['operaciones' => $st->fetchAll(), 'cupos' => cupos()]);

case 'GET operacion':
    $st = db()->prepare('SELECT * FROM operaciones WHERE id=?');
    $st->execute([(int)($_GET['id'] ?? 0)]);
    $o = $st->fetch() ?: fail('Operación no encontrada', 404);
    $o['datos'] = json_decode($o['datos'], true);
    out(['operacion' => $o]);

case 'POST guardar_operacion':
    $b = body();
    $c = $b['comprador'] ?? []; $o = $b['operacion'] ?? [];
    $id = isset($b['id']) ? (int)$b['id'] : null;
    $a = ajustes();

    // Validaciones de servidor (las de detalle se hacen además en el formulario)
    $tipo = $c['tipo'] ?? '';
    if (!in_array($tipo, ['natural','juridica'], true)) fail('Tipo de comprador inválido');
    $docTipo = ($tipo === 'natural' && ($c['doc_tipo'] ?? 'rut') === 'pasaporte') ? 'pasaporte' : 'rut';
    $doc = trim((string)($c['documento'] ?? ''));
    if ($docTipo === 'rut') { if (!rut_valido($doc)) fail('El RUT/RUN del comprador no es válido'); $doc = rut_normal($doc); }
    elseif (strlen($doc) < 5) fail('Número de pasaporte inválido');
    $nombre = trim((string)($c['nombre'] ?? ''));
    if (mb_strlen($nombre) < 3) fail('Falta el nombre o razón social del comprador');
    $email = strtolower(trim((string)($c['email'] ?? '')));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Correo del comprador inválido');
    if ($tipo === 'juridica' && !rut_valido((string)($c['rep_documento'] ?? ''))) fail('RUN del representante inválido');

    $serie = $o['serie'] ?? '';
    if (!in_array($serie, ['B','C'], true)) fail('Serie inválida');
    $cant = (int)($o['cantidad'] ?? 0);
    $precio = (int)($o['precio'] ?? 0);
    if ($cant <= 0) fail('La cantidad de acciones debe ser mayor que cero');
    if ($precio <= 0) fail('El precio por acción debe ser mayor que cero');
    if ($serie === 'C' && $precio < (int)$a['c_precio_minimo']) fail('El precio Serie C no puede ser inferior a $' . number_format((int)$a['c_precio_minimo'], 0, ',', '.'));
    $total = $cant * $precio;
    if ((int)($o['total'] ?? 0) !== $total) fail('El total no cuadra con cantidad × precio');
    $forma = $o['forma_pago'] ?? '';
    if (!in_array($forma, ['contado','parcial'], true)) fail('Forma de pago inválida');
    $fecha = (string)($o['fecha_contrato'] ?? '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha)) fail('Fecha del contrato inválida');
    if ($forma === 'parcial') {
        $pie = (int)($o['pie_monto'] ?? 0);
        if ($pie <= 0 || $pie >= $total) fail('El pago inicial debe ser mayor que cero y menor que el total');
        $ultima = (string)($o['cuota_ultima'] ?? '');
        if ($serie === 'C' && $ultima > $a['c_plazo_maximo']) fail('La última cuota no puede vencer después del ' . $a['c_plazo_maximo']);
    }

    $pdo = db();
    $pdo->beginTransaction();
    // Bloqueo de cupo dentro de la transacción
    $pdo->query("SELECT id FROM operaciones WHERE serie=" . $pdo->quote($serie) . " FOR UPDATE");
    $cup = cupos($id)[$serie];
    if ($cant > $cup['disponible']) { $pdo->rollBack(); fail('Cantidad supera las acciones disponibles de la Serie ' . $serie . ' (' . number_format($cup['disponible'], 0, ',', '.') . ')'); }

    // Comprador: alta o actualización por documento
    $st = $pdo->prepare('SELECT id FROM compradores WHERE doc_tipo=? AND documento=?');
    $st->execute([$docTipo, $doc]);
    $cid = $st->fetchColumn();
    $c['documento'] = $doc; $c['email'] = $email;
    $datosC = json_encode($c, JSON_UNESCAPED_UNICODE);
    if ($cid) {
        $pdo->prepare('UPDATE compradores SET tipo=?, nombre=?, email=?, telefono=?, comuna=?, region=?, datos=? WHERE id=?')
            ->execute([$tipo, $nombre, $email, $c['telefono'] ?? null, $c['comuna'] ?? null, $c['region'] ?? null, $datosC, $cid]);
    } else {
        $pdo->prepare('INSERT INTO compradores (tipo, doc_tipo, documento, nombre, email, telefono, comuna, region, datos, creado_por) VALUES (?,?,?,?,?,?,?,?,?,?)')
            ->execute([$tipo, $docTipo, $doc, $nombre, $email, $c['telefono'] ?? null, $c['comuna'] ?? null, $c['region'] ?? null, $datosC, $user['id']]);
        $cid = (int)$pdo->lastInsertId();
    }

    $datosO = json_encode(['comprador' => $c, 'operacion' => $o], JSON_UNESCAPED_UNICODE);
    if ($id) {
        $st = $pdo->prepare('SELECT estado, folio FROM operaciones WHERE id=? FOR UPDATE');
        $st->execute([$id]);
        $prev = $st->fetch();
        if (!$prev) { $pdo->rollBack(); fail('Operación no encontrada', 404); }
        if (!in_array($prev['estado'], ['borrador','generada'], true)) { $pdo->rollBack(); fail('La operación está ' . $prev['estado'] . ' y no puede modificarse. Use «Duplicar».'); }
        $pdo->prepare('UPDATE operaciones SET serie=?, comprador_id=?, cantidad=?, precio_unitario=?, total=?, forma_pago=?, fecha_contrato=?, datos=? WHERE id=?')
            ->execute([$serie, $cid, $cant, $precio, $total, $forma, $fecha, $datosO, $id]);
        $folio = $prev['folio'];
    } else {
        $anio = substr($fecha, 0, 4);
        $pref = "ODO-$serie-$anio-";
        $st = $pdo->prepare('SELECT folio FROM operaciones WHERE folio LIKE ? ORDER BY folio DESC LIMIT 1 FOR UPDATE');
        $st->execute([$pref . '%']);
        $ult = $st->fetchColumn();
        $n = $ult ? (int)substr($ult, strlen($pref)) + 1 : 1;
        $folio = $pref . str_pad((string)$n, 4, '0', STR_PAD_LEFT);
        $pdo->prepare('INSERT INTO operaciones (folio, serie, comprador_id, cantidad, precio_unitario, total, forma_pago, fecha_contrato, estado, datos, creado_por) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
            ->execute([$folio, $serie, $cid, $cant, $precio, $total, $forma, $fecha, 'borrador', $datosO, $user['id']]);
        $id = (int)$pdo->lastInsertId();
    }
    $pdo->commit();
    bitacora('guardar_operacion', ['id' => $id, 'folio' => $folio, 'comprador' => $doc]);
    out(['ok' => true, 'id' => $id, 'folio' => $folio, 'comprador_id' => $cid]);

case 'POST subir_pdf':
    $b = body();
    $id = (int)($b['id'] ?? 0);
    $bin = base64_decode((string)($b['pdf'] ?? ''), true);
    if ($bin === false || substr($bin, 0, 5) !== '%PDF-') fail('Archivo PDF inválido');
    if (strlen($bin) > 15 * 1024 * 1024) fail('PDF demasiado grande');
    $st = db()->prepare('SELECT folio, estado, version FROM operaciones WHERE id=?');
    $st->execute([$id]);
    $op = $st->fetch() ?: fail('Operación no encontrada', 404);
    if (!in_array($op['estado'], ['borrador','generada'], true)) fail('La operación no admite nuevas versiones');
    $ver = (int)$op['version'] + 1;
    $file = $op['folio'] . '-v' . $ver . '.pdf';
    file_put_contents(storage_dir('minutas') . '/' . $file, $bin);
    $sha = hash('sha256', $bin);
    db()->prepare("UPDATE operaciones SET estado='generada', version=?, pdf_archivo=?, pdf_sha256=? WHERE id=?")
        ->execute([$ver, $file, $sha, $id]);
    bitacora('generar_pdf', ['id' => $id, 'folio' => $op['folio'], 'version' => $ver, 'sha256' => $sha]);
    out(['ok' => true, 'version' => $ver, 'sha256' => $sha, 'cupos' => cupos()]);

case 'GET pdf':
    $st = db()->prepare('SELECT folio, pdf_archivo FROM operaciones WHERE id=?');
    $st->execute([(int)($_GET['id'] ?? 0)]);
    $op = $st->fetch();
    $path = $op && $op['pdf_archivo'] ? storage_dir('minutas') . '/' . basename($op['pdf_archivo']) : '';
    if (!$path || !is_file($path)) fail('PDF no disponible', 404);
    header('Content-Type: application/pdf');
    header('Content-Disposition: ' . (isset($_GET['descargar']) ? 'attachment' : 'inline') . '; filename="' . $op['pdf_archivo'] . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;

case 'POST estado':
    $b = body();
    $id = (int)($b['id'] ?? 0); $nuevo = $b['estado'] ?? '';
    $st = db()->prepare('SELECT folio, estado FROM operaciones WHERE id=?');
    $st->execute([$id]);
    $op = $st->fetch() ?: fail('Operación no encontrada', 404);
    $permitido = [
        'generada' => ['firmada', 'anulada'],
        'borrador' => ['anulada'],
        'firmada'  => ['anulada'],
    ];
    if (!in_array($nuevo, $permitido[$op['estado']] ?? [], true)) fail('Cambio de estado no permitido');
    $motivo = null;
    if ($nuevo === 'anulada') {
        if ($op['estado'] === 'firmada') master_only();
        $motivo = trim((string)($b['motivo'] ?? ''));
        if (mb_strlen($motivo) < 5) fail('Indique el motivo de la anulación');
    }
    db()->prepare('UPDATE operaciones SET estado=?, motivo_anulacion=COALESCE(?, motivo_anulacion) WHERE id=?')->execute([$nuevo, $motivo, $id]);
    bitacora('estado_operacion', ['id' => $id, 'folio' => $op['folio'], 'de' => $op['estado'], 'a' => $nuevo, 'motivo' => $motivo]);
    out(['ok' => true, 'cupos' => cupos()]);

// ── Usuarios (máster) ───────────────────────────────────────────────────
case 'GET usuarios':
    master_only();
    out(['usuarios' => db()->query('SELECT id, email, nombre, rol, activo, debe_cambiar, ultimo_ingreso, creado_en FROM usuarios ORDER BY rol, email')->fetchAll()]);

case 'POST usuario_crear':
    master_only();
    $b = body();
    $email = strtolower(trim((string)($b['email'] ?? '')));
    $nombre = trim((string)($b['nombre'] ?? ''));
    $clave = (string)($b['clave'] ?? '');
    $rol = ($b['rol'] ?? 'usuario') === 'master' ? 'master' : 'usuario';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) fail('Correo inválido');
    if (mb_strlen($nombre) < 2) fail('Indique el nombre');
    if (strlen($clave) < 6) fail('La clave inicial debe tener al menos 6 caracteres');
    $st = db()->prepare('SELECT COUNT(*) FROM usuarios WHERE email=?'); $st->execute([$email]);
    if ($st->fetchColumn()) fail('Ya existe un usuario con ese correo');
    db()->prepare('INSERT INTO usuarios (email, nombre, rol, pass_hash, debe_cambiar) VALUES (?,?,?,?,1)')
        ->execute([$email, $nombre, $rol, password_hash($clave, PASSWORD_DEFAULT)]);
    bitacora('usuario_crear', ['email' => $email, 'rol' => $rol]);
    out(['ok' => true]);

case 'POST usuario_actualizar':
    master_only();
    $b = body();
    $id = (int)($b['id'] ?? 0);
    if ($id === (int)$user['id'] && (isset($b['activo']) && !$b['activo'])) fail('No puede desactivar su propia cuenta');
    if (isset($b['activo'])) db()->prepare('UPDATE usuarios SET activo=? WHERE id=?')->execute([$b['activo'] ? 1 : 0, $id]);
    if (!empty($b['clave'])) {
        if (strlen((string)$b['clave']) < 6) fail('La clave temporal debe tener al menos 6 caracteres');
        db()->prepare('UPDATE usuarios SET pass_hash=?, debe_cambiar=1, intentos_fallidos=0, bloqueado_hasta=NULL WHERE id=?')
            ->execute([password_hash((string)$b['clave'], PASSWORD_DEFAULT), $id]);
    }
    bitacora('usuario_actualizar', ['id' => $id, 'activo' => $b['activo'] ?? null, 'reset_clave' => !empty($b['clave'])]);
    out(['ok' => true]);

case 'GET bitacora':
    master_only();
    out(['bitacora' => db()->query('SELECT b.creado_en, b.accion, b.detalle, b.ip, u.email FROM bitacora b LEFT JOIN usuarios u ON u.id=b.usuario_id ORDER BY b.id DESC LIMIT 300')->fetchAll()]);

default:
    fail('Acción desconocida', 404);
}
} catch (Throwable $e) {
    if (db()->inTransaction()) db()->rollBack();
    error_log('[minutas-odo] ' . $e->getMessage());
    fail('Error interno del servidor', 500);
}
