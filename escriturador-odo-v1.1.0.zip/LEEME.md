# Minutas ODO — instalación en SiteGround

Plataforma web para generar contratos de compraventa de acciones **Serie C** (vende ODO, colocación
de primera emisión) y **Serie B** (vende IVELSA, cesión de acciones ya pagadas), listos para firma
electrónica en FirmaYa.

PHP 8.1 o superior y MySQL. Funciona en cualquier plan de SiteGround (StartUp incluido). No requiere
Node.js, Composer ni compilación.

## 1. Crear la base de datos

Site Tools → **Sitio → MySQL**:

1. Pestaña *Bases de datos* → **Crear base de datos**. Anote el nombre (p. ej. `dbxxxxx_minutas`).
2. Pestaña *Usuarios* → **Crear usuario**. Anote usuario y contraseña.
3. En la base creada, **Añadir usuario** → elija el usuario → permisos **Todos los privilegios**.

## 2. Subir los archivos

1. Cree un subdominio si lo desea (Site Tools → Dominio → Subdominios), p. ej. `minutas.odo.cl`.
2. Site Tools → **Sitio → Administrador de archivos**, entre a la carpeta `public_html` del subdominio.
3. Suba el ZIP y use **Extraer**. Deben quedar `index.php`, `api.php`, `assets/`, `lib/`, `storage/`, etc.
   directamente en esa carpeta (no dentro de una subcarpeta `minutas/`).

## 3. Configurar

1. Duplique `config.sample.php` y renómbrelo `config.php`.
2. Edítelo y complete `name`, `user` y `password` con los datos del paso 1. `host` queda `localhost`.
3. Recomendado: guardar los PDF fuera de `public_html`. Cree la carpeta `/home/customer/minutas-storage`
   (o la ruta equivalente que muestre el administrador de archivos, un nivel sobre `public_html`) y
   cambie `storage_dir` a esa ruta. Si deja la carpeta interna `storage/`, el `.htaccess` incluido
   bloquea el acceso directo.

## 4. HTTPS

Site Tools → **Seguridad → Administrador SSL**: instale el certificado Let's Encrypt del dominio.
La plataforma redirige automáticamente a HTTPS.

## 5. Instalar

Abra `https://SU-DOMINIO/install.php` y pulse **Instalar**. Se crean las tablas, el usuario máster y
los ajustes iniciales. **Luego borre `install.php`** desde el administrador de archivos.

## 6. Primer ingreso

- Usuario: `master@odo.cl`
- Clave inicial: `123odo`

Al ingresar, el sistema exige cambiar la clave (mínimo 8 caracteres, letras y números). Después puede
cambiarla cuando quiera desde el menú del usuario → **Cambiar clave**.

## 7. Completar Ajustes (solo máster)

Menú **Ajustes**. Los campos en amarillo están pendientes y bloquean la generación de minutas de la
serie que los usa:

- **IVELSA (Serie B):** giro, domicilio, estado civil y profesión del representante, personería,
  banco, número de cuenta y correo para comprobantes.
- **ODO (Serie C):** revise el domicilio (los estatutos dicen Providencia; el SII registra Teatinos 770)
  y los datos del Gerente General.

## Uso

1. **Nueva minuta** → elegir Serie C o Serie B.
2. **Comprador**: persona natural o jurídica. Busque por RUT o nombre para reutilizar un comprador ya
   registrado; al escribir un RUT existente se ofrece cargar sus datos.
3. **Operación y pago**: cantidad y precio libres (el sistema calcula el total, el monto con recargo de
   tarjeta y las cuotas). Serie C valida el precio mínimo, el cupo disponible y que la última cuota no
   pase del 27-08-2029. El pago al contado (o el pie, si es en cuotas) se hace **al firmar o después**:
   el contrato fija un plazo de días hábiles contados desde la última firma en FirmaYa (3 por defecto;
   se cambia en Ajustes → Comunes → «Días hábiles para pagar el contado o el pie»).
4. **Declaraciones**: origen de fondos, inversión extranjera, días para inscribir, testigos
   (obligatorios en Serie B).
5. **Revisión y PDF**: lista de datos pendientes (clic para ir al campo). Con todo validado, **Validar y
   generar PDF**: el comprador queda en la base, la operación recibe folio (`ODO-C-2026-0001`), el PDF se
   archiva con su huella SHA-256 y se abre en el visor. **Descargar para firma** y subirlo a FirmaYa.
6. En **Operaciones**, una vez firmado, marcar **Firmada**. Mientras esté «generada» se puede editar y
   regenerar (nueva versión, mismo folio). **Anular** libera el cupo; una firmada solo la anula el máster.

El formulario en curso se guarda en el navegador: si se cierra la pestaña, al volver se retoma.

## Perfiles

| Acción | Usuario | Máster |
|---|---|---|
| Generar, editar y ver minutas | ✓ | ✓ |
| Marcar firmada, anular no firmadas | ✓ | ✓ |
| Anular firmadas | | ✓ |
| Ajustes, usuarios, bitácora, exportar compradores (CSV) | | ✓ |

Los usuarios nuevos reciben una clave temporal y deben cambiarla al primer ingreso. Cinco intentos
fallidos bloquean la cuenta por 15 minutos.

## Respaldo

La base (compradores, operaciones, bitácora) queda en los respaldos diarios de SiteGround. Los PDF
archivados están en `storage_dir`: inclúyala en sus respaldos si la movió fuera de `public_html`.

## Estructura

```
index.php            aplicación (requiere sesión)
api.php              API JSON
login.php, logout.php, cambiar-clave.php, install.php
config.sample.php    plantilla de configuración → config.php
lib/                 arranque, esquema SQL y valores iniciales de Ajustes (bloqueado a la web)
assets/minuta.js     redacción de los contratos Serie B y C y armado del PDF
assets/app.js        formulario, validaciones y vistas
assets/vendor/       pdfmake 0.2.23 y tipografía Liberation Serif
storage/             PDF archivados (bloqueado a la web)
```

Los textos de las cláusulas están en `assets/minuta.js` (funciones `clausulasC` y `clausulasB`).

## Cambios v1.1.0

- El comprador paga al firmar o después, no antes: la cláusula de pago ya no declara el precio (o el pie)
  recibido, sino que el comprador lo pagará dentro de N días hábiles desde la última firma electrónica.
- Nuevo ajuste `plazo_pago_dias` (3 por defecto). Se eliminaron los campos «Fecha en que se recibió el pago»
  y «Fecha del pago inicial» y sus validaciones.
- Serie C: las acciones quedan pagadas cuando la sociedad recibe el precio; mientras tanto rige el Art.
  Octavo (sin voto) y, en mora, el Art. Noveno. Serie B: el retardo devenga el interés máximo
  convencional; en cuotas, el retardo del pie o de una cuota hace exigible el saldo.
- Actualizar: reemplazar `assets/`, `lib/bootstrap.php` y `lib/defaults.php`. No hay cambios en la base
  de datos.
