<?php
declare(strict_types=1);

const APP_VERSION = '1.1.0';
define('APP_ROOT', dirname(__DIR__));

function app_config(): array {
    static $cfg = null;
    if ($cfg === null) {
        $file = APP_ROOT . '/config.php';
        if (!is_file($file)) {
            http_response_code(500);
            exit('Falta config.php. Copie config.sample.php como config.php y complete los datos de la base.');
        }
        $cfg = require $file;
        date_default_timezone_set($cfg['timezone'] ?? 'America/Santiago');
    }
    return $cfg;
}

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $c = app_config()['db'];
        $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $c['host'], (int)($c['port'] ?? 3306), $c['name']);
        $pdo = new PDO($dsn, $c['user'], $c['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $pdo->exec("SET time_zone = '" . (new DateTime())->format('P') . "'");
    }
    return $pdo;
}

function storage_dir(string $sub = ''): string {
    $dir = rtrim(app_config()['storage_dir'] ?? (APP_ROOT . '/storage'), '/');
    if ($sub !== '') $dir .= '/' . $sub;
    if (!is_dir($dir)) mkdir($dir, 0750, true);
    return $dir;
}

function is_installed(): bool {
    return is_file(storage_dir() . '/.instalado');
}

function start_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_name(app_config()['session_name'] ?? 'odo_minutas');
    session_set_cookie_params([
        'lifetime' => 0, 'path' => '/', 'secure' => $https,
        'httponly' => true, 'samesite' => 'Strict',
    ]);
    session_start();
    // Expira tras 8 horas de inactividad
    if (isset($_SESSION['t']) && time() - $_SESSION['t'] > 8 * 3600) {
        $_SESSION = [];
        session_destroy();
        session_start();
    }
    $_SESSION['t'] = time();
}

function csrf_token(): string {
    start_session();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function check_csrf(?string $token): bool {
    start_session();
    return is_string($token) && !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
}

function current_user(): ?array {
    start_session();
    if (empty($_SESSION['uid'])) return null;
    static $u = false;
    if ($u === false) {
        $st = db()->prepare('SELECT id, email, nombre, rol, activo FROM usuarios WHERE id = ?');
        $st->execute([$_SESSION['uid']]);
        $u = $st->fetch() ?: null;
        if ($u && !$u['activo']) $u = null;
    }
    return $u;
}

function require_login_page(): array {
    if (!is_installed()) { header('Location: install.php'); exit; }
    $u = current_user();
    if (!$u) { header('Location: login.php'); exit; }
    return $u;
}

function h(?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function bitacora(string $accion, array $detalle = []): void {
    $u = current_user();
    $st = db()->prepare('INSERT INTO bitacora (usuario_id, accion, detalle, ip) VALUES (?,?,?,?)');
    $st->execute([$u['id'] ?? null, $accion, json_encode($detalle, JSON_UNESCAPED_UNICODE), $_SERVER['REMOTE_ADDR'] ?? '']);
}

function ajustes(): array {
    $defaults = require __DIR__ . '/defaults.php';
    $rows = db()->query('SELECT clave, valor FROM ajustes')->fetchAll();
    foreach ($rows as $r) $defaults[$r['clave']] = $r['valor'];
    return $defaults;
}

function security_headers(): void {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
}
