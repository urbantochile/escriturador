<?php
/*
 * Valores iniciales de «Ajustes». Se copian a la base al instalar y luego se
 * editan desde la aplicación. Los marcados «COMPLETAR» deben revisarse antes
 * de generar la primera minuta: el sistema no genera PDF si queda alguno.
 */
return [
    // ── ODO (vendedora en Serie C) ───────────────────────────────────────
    'odo_razon'          => 'ODO SERVICIOS FINANCIEROS SpA',
    'odo_fantasia'       => 'ODO SpA',
    'odo_rut'            => '78.513.672-1',
    'odo_giro'           => 'servicios tecnológicos para el ecosistema Fintech',
    'odo_domicilio'      => 'Calle Las Bellotas número 1.666, Oficina 62, comuna de Providencia, Región Metropolitana de Santiago',
    'odo_rep_trat'       => 'don',
    'odo_rep_nombre'     => 'VINCENT IAN QUIROGA ROJAS',
    'odo_rep_nacionalidad' => 'chileno',
    'odo_rep_estado_civil' => 'soltero',
    'odo_rep_profesion'  => 'contador público y auditor',
    'odo_rep_run'        => '17.133.653-8',
    'odo_rep_cargo'      => 'Gerente General',
    'odo_rep_personeria' => 'el Artículo Tercero Transitorio de la escritura pública de constitución de la sociedad de fecha veintisiete de agosto de dos mil veintiséis, otorgada en la Cuadragésimo Octava Notaría de Santiago, ante el Notario Suplente don Marcelo Andrés Donoso Araya, repertorio número 11.522-2026',
    'odo_antecedentes'   => 'ODO SERVICIOS FINANCIEROS SpA se constituyó por escritura pública de fecha veintisiete de agosto de dos mil veintiséis, otorgada en la Cuadragésimo Octava Notaría de Santiago, ante el Notario Suplente don Marcelo Andrés Donoso Araya, repertorio número 11.522-2026. Su extracto se inscribió a fojas 84.480 número 31.728 del Registro de Comercio del Conservador de Bienes Raíces de Santiago correspondiente al año dos mil veintiséis, y se publicó en el Diario Oficial de fecha cinco de septiembre de dos mil veintiséis. La sociedad se rige por los artículos cuatrocientos veinticuatro y siguientes del Código de Comercio, en subsidio por la Ley número dieciocho mil cuarenta y seis y su Reglamento, y por la Ley número veintiún mil quinientos veintiuno.',

    // ── Medios de pago Serie C (cuenta de ODO) ───────────────────────────
    'c_cuenta_mp'        => '1021461854',
    'c_link_pago'        => 'https://link.mercadopago.cl/odo',
    'c_recargo_tarjeta'  => '2.2',
    'c_correo_pagos'     => 'finanzas@odo.cl',

    // ── Límites Serie C ──────────────────────────────────────────────────
    'c_total_serie'      => '2000000',
    'c_precio_minimo'    => '200',
    'c_plazo_maximo'     => '2029-08-27',

    // ── IVELSA (vendedora en Serie B) ────────────────────────────────────
    'iv_razon'           => 'RENTAS E INVERSIONES VALLE ELQUI S.A.',
    'iv_rut'             => '76.138.821-5',
    'iv_giro'            => 'inversiones',
    'iv_domicilio'       => 'calle San Joaquín número 1.666, comuna de La Serena, Región de Coquimbo',
    'iv_rep_trat'        => 'don',
    'iv_rep_nombre'      => 'FRANCISCO JAVIER GUTIÉRREZ MALDONADO',
    'iv_rep_nacionalidad'=> 'chileno',
    'iv_rep_estado_civil'=> 'casado',
    'iv_rep_profesion'   => 'ingeniero',
    'iv_rep_run'         => '10.629.397-K',
    // Personería: certificado de poderes del Registro de Empresas y Sociedades (fecha AAAA-MM-DD y CVE)
    'iv_pers_fecha'      => '',
    'iv_pers_cve'        => '',
    'b_banco'            => 'Banco Itaú',
    'b_tipo_cuenta'      => 'cuenta corriente',
    'b_cuenta'           => '0223801122',
    'b_correo_pagos'     => 'finanzas@ivelsa.cl',
    'b_tenencia_inicial' => '330000',

    // ── Comunes ──────────────────────────────────────────────────────────
    'abogado_nombre'     => 'don Antonio Alejandro Jesús Martínez Claussen',
    'abogado_run'        => '14.401.074-4',
    'ciudad_firma'       => 'Santiago',
    'dias_registro'      => '5',
    'plazo_pago_dias'    => '3',   // días hábiles para pagar el contado o el pie, desde la última firma
    'plataforma_firma'   => 'FirmaYa',
];
